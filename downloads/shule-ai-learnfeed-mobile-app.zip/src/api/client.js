// Shule AI LearnFeed API client.
// Default points to the ShuleAI backend. Override with EXPO_PUBLIC_SHULEAI_API_BASE_URL when needed.

const DEFAULT_BASE_URL = 'https://shuleaibackend-32h1.onrender.com/api/learnfeed';
const BASE_URL = (typeof process !== 'undefined' && process.env?.EXPO_PUBLIC_SHULEAI_API_BASE_URL) || DEFAULT_BASE_URL;

let authToken = null;
let currentUser = null;

function setToken(token) {
  authToken = token || null;
}

function setCurrentUser(user) {
  currentUser = user || null;
}

function queryString(params = {}) {
  const search = Object.entries(params)
    .filter(([, value]) => value !== undefined && value !== null && value !== '')
    .map(([key, value]) => encodeURIComponent(key) + '=' + encodeURIComponent(String(value)))
    .join('&');
  return search ? '?' + search : '';
}

async function request(method, path, body, options = {}) {
  const headers = { Accept: 'application/json', 'Content-Type': 'application/json' };
  if (options.auth !== false && authToken) headers.Authorization = 'Bearer ' + authToken;
  const res = await fetch(BASE_URL + path, {
    method,
    headers,
    body: method === 'GET' ? undefined : JSON.stringify(body || {}),
  });
  const text = await res.text();
  let json = null;
  try { json = text ? JSON.parse(text) : null; } catch { json = { raw: text }; }
  if (!res.ok || json?.success === false) {
    const error = new Error(json?.message || json?.error || 'Request failed');
    error.status = res.status;
    error.body = json;
    throw error;
  }
  return json || { success: true };
}

function oneId(first, second) {
  return second === undefined ? first : second;
}

export const api = {
  baseUrl: BASE_URL,
  auth: {
    setToken,
    getToken: () => authToken,
    getCurrentUser: () => currentUser,
    login: async (emailOrElimuId, password, role, extra = {}) => {
      const payload = { email: emailOrElimuId, emailOrPhone: emailOrElimuId, password, role, accountScope: 'individual', accessType: 'public', isSchoolLinked: false, ...extra };
      if (extra.elimuid || extra.elimuId) { delete payload.email; delete payload.emailOrPhone; }
      const result = await request('POST', '/auth/login', payload, { auth: false });
      setToken(result?.data?.token);
      setCurrentUser(result?.data?.user);
      return result;
    },
    register: async (payload) => {
      const result = await request('POST', '/auth/register', { ...payload, accountScope: 'individual', accessType: 'public', isSchoolLinked: false }, { auth: false });
      setToken(result?.data?.token);
      setCurrentUser(result?.data?.user);
      return result;
    },
    me: () => request('GET', '/auth/me'),
    linkPlatformStudent: (elimuid, platformPassword) => request('POST', '/auth/link-platform-student', { elimuid, platformPassword }),
    logout: async () => {
      try { await request('POST', '/auth/logout'); } finally { setToken(null); setCurrentUser(null); }
      return { success: true };
    },
  },
  feed: {
    list: (userOrOptions, page = 0, feed = 'for-you') => {
      const opts = typeof userOrOptions === 'object' && userOrOptions !== null ? userOrOptions : { page, feed };
      return request('GET', '/feed' + queryString(opts));
    },
    like: (userId, videoId) => request('POST', '/feed/like', { videoId: oneId(userId, videoId) }),
    save: (userId, videoId) => request('POST', '/feed/save', { videoId: oneId(userId, videoId) }),
    follow: (userId, creatorId, videoId) => request('POST', '/feed/follow', { creatorId: oneId(userId, creatorId), videoId }),
    notInterested: (userId, videoId) => request('POST', '/feed/not-interested', { videoId: oneId(userId, videoId) }),
  },
  video: {
    upload: (userId, payload) => request('POST', '/videos/upload', { userId, ...payload }),
    publish: (userId, payload) => request('POST', '/videos/publish', { userId, ...payload }),
    report: (userId, videoId, reason) => request('POST', '/videos/report', { userId, videoId, reason }),
    remix: (userId, sourceVideoId, mode) => request('POST', '/videos/remix', { userId, sourceVideoId, mode }),
  },
  comments: {
    list: (videoId) => request('GET', '/comments' + queryString({ videoId }), undefined, { auth: false }),
    add: (userId, videoId, text) => request('POST', '/comments/add', { userId, videoId, text }),
    like: (userId, commentId) => request('POST', '/comments/like', { userId, commentId }),
  },
  live: {
    rooms: () => request('GET', '/live/rooms', undefined, { auth: false }),
    start: (userId, payload) => request('POST', '/live/start', { userId, ...payload }),
    end: (userId, roomId) => request('POST', '/live/end', { userId, roomId }),
    chat: (userId, roomId, text) => request('POST', '/live/chat', { userId, roomId, text }),
    gift: (userId, roomId, giftId) => request('POST', '/live/gift', { userId, roomId, giftId }),
  },
  sounds: {
    list: () => request('GET', '/sounds', undefined, { auth: false }),
    use: (userId, soundId) => request('POST', '/sounds/use', { userId, soundId }),
  },
  ai: {
    ask: (userId, videoId, text) => request('POST', '/ai/ask', { userId, videoId, text }),
  },
  quiz: {
    submit: (userId, videoId, answer) => request('POST', '/quiz/submit', { userId, videoId, answer }),
  },
  messages: {
    inbox: (userId) => request('GET', '/messages/inbox' + queryString({ userId })),
    send: (fromId, toId, text) => request('POST', '/messages/send', { fromId, toId, text }),
  },
  billing: {
    plans: () => request('GET', '/billing/public-plans', undefined, { auth: false }),
    checkout: (userId, planId, provider, phone) => request('POST', '/billing/user-subscription/checkout', { userId, planId, provider, phone, accountScope: 'individual', paymentScope: 'user', isSchoolLinked: false }),
    status: (reference) => request('GET', '/billing/status/' + encodeURIComponent(reference)),
    wallet: (userId) => request('GET', '/billing/wallet' + queryString({ userId })),
    withdraw: (userId, amount, provider) => request('POST', '/billing/withdraw', { userId, amount, provider }),
  },
};
