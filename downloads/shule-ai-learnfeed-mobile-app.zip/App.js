import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Dimensions,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { api } from './src/api/client';

const colors = {
  bg: '#0A0E1A',
  bgCard: '#141928',
  bgCard2: '#1A2235',
  bgInput: '#1E2840',
  navBg: '#0D1120',
  teal: '#00C2BA',
  tealDark: '#009E96',
  tealLight: '#3DD8D2',
  blue: '#083A85',
  deepBlue: '#0B2F6B',
  pink: '#FF3B5C',
  gold: '#FFD700',
  purple: '#7B5CF6',
  green: '#00C875',
  white: '#FFFFFF',
  textSub: '#8A9BBF',
  textMuted: '#5A6B8A',
  line: 'rgba(255,255,255,0.08)',
  lineStrong: 'rgba(255,255,255,0.15)',
  danger: '#FF3B5C',
  warning: '#FFB800',
};

const { height: SH, width: SW } = Dimensions.get('window');
const TAB_H = 72;
const FEED_H = SH - TAB_H;

const starterVideos = [
  {
    id: 'v1', subject: 'CHEMISTRY', className: 'Form 3', title: 'Titration Explained',
    description: 'Acid-base titration, end point, burette reading, and concentration calculation.',
    creator: 'Brian Otieno', handle: '@brianchem', role: 'Chemistry Teacher', avatar: '👨🏾‍🏫', verified: true,
    likes: 12400, comments: 342, saves: 2100, shares: 1300, views: '128K', sound: 'Original Sound - Brian Otieno',
    topic: 'Titration', visualEmoji: '🧪', live: false, following: false,
    question: 'Which equipment delivers titrant drop by drop?', options: ['Burette', 'Thermometer', 'Tripod stand', 'Filter paper'], answer: 0,
    aiContext: 'Titration uses a burette to deliver titrant into an analyte until the indicator changes color at the end point.',
  },
  {
    id: 'v2', subject: 'MATHEMATICS', className: 'Form 3', title: 'Quadratic Formula Fast Method',
    description: 'How to identify a, b, c and solve quadratic equations step by step.',
    creator: 'Miss Amina', handle: '@aminaMaths', role: 'Math Teacher', avatar: '👩🏾‍🏫', verified: true,
    likes: 8700, comments: 98, saves: 2500, shares: 420, views: '76K', sound: 'Original Sound - Miss Amina',
    topic: 'Quadratics', visualEmoji: '📐', live: true, following: true,
    question: 'The standard quadratic form is:', options: ['ax+b=0', 'ax²+bx+c=0', 'y=mx+c', 'a²+b²=c²'], answer: 1,
    aiContext: 'A quadratic equation has x squared as the highest power and can be solved by factoring, completing square, or formula.',
  },
  {
    id: 'v3', subject: 'BIOLOGY', className: 'Form 2', title: 'Photosynthesis in 60 Seconds',
    description: 'Plants use sunlight, carbon dioxide, and water to make glucose and oxygen.',
    creator: 'Ms. Wanjiru', handle: '@bioWanjiru', role: 'Biology Teacher', avatar: '👩🏾‍🔬', verified: true,
    likes: 5200, comments: 86, saves: 1800, shares: 210, views: '58K', sound: 'Original Sound - Ms. Wanjiru',
    topic: 'Photosynthesis', visualEmoji: '🌱', live: false, following: false,
    question: 'Main gas released in photosynthesis?', options: ['Carbon dioxide', 'Oxygen', 'Nitrogen', 'Hydrogen'], answer: 1,
    aiContext: 'Photosynthesis happens in chloroplasts. Chlorophyll absorbs light. Oxygen is released as a by-product.',
  },
  {
    id: 'v4', subject: 'PHYSICS', className: 'Form 3', title: "Newton's Laws with Real Examples",
    description: 'Motion, force, acceleration, inertia, and action-reaction explained clearly.',
    creator: 'Mr. Kariuki', handle: '@physicsK', role: 'Physics Teacher', avatar: '👨🏾‍🔬', verified: true,
    likes: 9100, comments: 157, saves: 1700, shares: 430, views: '94K', sound: 'Original Sound - Mr. Kariuki',
    topic: 'Motion', visualEmoji: '⚙️', live: true, following: true,
    question: "Newton's second law is:", options: ['F=ma', 'V=IR', 'P=IV', 'E=mc²'], answer: 0,
    aiContext: 'Newton second law says force equals mass times acceleration. Direction of force matches acceleration.',
  },
];

const liveRoomsSeed = [
  { id: 'l1', host: 'Miss Amina', handle: '@aminaMaths', title: 'Live: Quadratics KCSE Drill', subject: 'Mathematics', viewers: 1280, avatar: '👩🏾‍🏫', emoji: '📐' },
  { id: 'l2', host: 'Mr. Kariuki', handle: '@physicsK', title: 'Live: Newton Laws Q&A', subject: 'Physics', viewers: 845, avatar: '👨🏾‍🔬', emoji: '⚙️' },
  { id: 'l3', host: 'Teacher Brian', handle: '@brianchem', title: 'Live: Titration Lab Demo', subject: 'Chemistry', viewers: 532, avatar: '👨🏾‍🏫', emoji: '🧪' },
];

const soundLibrary = [
  { id: 's1', title: 'Original Sound - Study Beat', creator: 'LearnFeed', uses: '18.2K', icon: 'musical-notes' },
  { id: 's2', title: 'Soft Revision Lofi', creator: 'Shule AI', uses: '9.4K', icon: 'headset' },
  { id: 's3', title: 'Exam Focus Timer', creator: 'Creator Tools', uses: '4.1K', icon: 'timer' },
  { id: 's4', title: 'Teacher Voiceover', creator: 'Public Creators', uses: '12.7K', icon: 'mic' },
];

const effectLibrary = [
  { id: 'e1', name: 'Green Screen Notes', icon: 'albums-outline', color: colors.teal },
  { id: 'e2', name: 'Auto Captions', icon: 'text-outline', color: colors.gold },
  { id: 'e3', name: 'Quiz Sticker', icon: 'help-circle-outline', color: colors.pink },
  { id: 'e4', name: 'Whiteboard', icon: 'create-outline', color: colors.purple },
  { id: 'e5', name: 'Formula Overlay', icon: 'calculator-outline', color: colors.green },
  { id: 'e6', name: 'Beauty / Light', icon: 'sparkles-outline', color: colors.tealLight },
];

const initialMessages = [
  { id: 'm1', name: 'Grace Wanjiku', avatar: '👧🏾', subtitle: 'Student', last: 'Can you send the titration notes?', unread: 2, online: true },
  { id: 'm2', name: 'Kevin Mutisya', avatar: '👦🏾', subtitle: 'Student', last: 'Thanks for the quiz explanation!', unread: 0, online: false },
  { id: 'm3', name: 'Miss Amina', avatar: '👩🏾‍🏫', subtitle: 'Creator', last: 'Let us collab on algebra live.', unread: 1, online: true },
];

function formatCount(n) {
  if (typeof n === 'string') return n;
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
  return `${n}`;
}

function showToast(title, message) {
  Alert.alert(title, message || 'Done.');
}

function normalizeLearnFeedVideo(video) {
  return {
    ...video,
    id: String(video.id || Date.now()),
    creatorId: video.creatorId || video.userId || null,
    subject: String(video.subject || 'GENERAL').toUpperCase(),
    className: video.className || 'Public',
    title: video.title || 'LearnFeed Lesson',
    description: video.description || '',
    creator: video.creator || video.displayName || 'LearnFeed Creator',
    handle: video.handle || '@learnfeed',
    role: video.role || 'Creator',
    avatar: video.avatar || '🎓',
    likes: Number(video.likes || video.likesCount || 0),
    comments: Number(video.comments || video.commentsCount || 0),
    saves: Number(video.saves || video.savesCount || 0),
    shares: Number(video.shares || video.sharesCount || 0),
    views: video.views || String(video.viewsCount || 0),
    sound: video.sound || video.soundTitle || 'Original Sound - LearnFeed',
    topic: video.topic || video.subject || 'General',
    visualEmoji: video.visualEmoji || '🎓',
    question: video.question || video.quizQuestion || 'What is this lesson mainly about?',
    options: Array.isArray(video.options) && video.options.length ? video.options : (Array.isArray(video.quizOptions) && video.quizOptions.length ? video.quizOptions : ['Lesson topic', 'Gaming', 'Cooking', 'Travel']),
    answer: Number(video.answer ?? video.quizAnswerIndex ?? 0),
    aiContext: video.aiContext || 'This is a public LearnFeed lesson.',
  };
}

export default function App() {
  const [session, setSession] = useState(null);
  const [tab, setTab] = useState('feed');
  const [screen, setScreen] = useState(null);
  const [videos, setVideos] = useState(starterVideos);
  const [liveRooms, setLiveRooms] = useState(liveRoomsSeed);
  const [activeFeed, setActiveFeed] = useState('For You');

  useEffect(() => {
    if (!session) return undefined;
    let alive = true;
    const feedKey = activeFeed.toLowerCase().replace(/\s+/g, '-');
    api.feed.list({ feed: feedKey }).then((result) => {
      const nextVideos = result?.data?.videos || [];
      if (alive && Array.isArray(nextVideos) && nextVideos.length) setVideos(nextVideos.map(normalizeLearnFeedVideo));
    }).catch(() => {});
    api.live.rooms().then((result) => {
      const rooms = result?.data?.rooms || [];
      if (alive && Array.isArray(rooms) && rooms.length) setLiveRooms(rooms);
    }).catch(() => {});
    return () => { alive = false; };
  }, [session, activeFeed]);

  function open(type, data = null) {
    setScreen({ type, data });
  }
  function close() {
    setScreen(null);
  }
  function routeTab(nextTab) {
    setScreen(null);
    setTab(nextTab);
  }
  function patchVideo(id, patcher) {
    setVideos(prev => prev.map(v => v.id === id ? { ...v, ...(typeof patcher === 'function' ? patcher(v) : patcher) } : v));
  }
  async function publishVideo(payload) {
    const localVideo = {
      id: `user-${Date.now()}`,
      subject: payload.subject.toUpperCase(),
      className: payload.className,
      title: payload.caption || 'New LearnFeed Lesson',
      description: payload.description || 'A new lesson created from the full TikTok-style creator studio.',
      creator: session?.displayName || session?.email?.split('@')[0] || 'Teacher Creator',
      handle: session?.handle || '@publiccreator',
      role: session?.role === 'teacher' ? 'Teacher / Creator' : 'Student Creator',
      avatar: session?.role === 'teacher' ? '👨🏾‍🏫' : '🎓',
      verified: session?.role === 'teacher',
      likes: 0,
      comments: 0,
      saves: 0,
      shares: 0,
      views: '0',
      sound: payload.sound || 'Original Sound - Public Creator',
      topic: payload.subject,
      visualEmoji: payload.emoji || '🎓',
      live: false,
      following: false,
      question: `What is this lesson mainly about?`,
      options: [payload.subject, 'Gaming', 'Cooking', 'Travel'],
      answer: 0,
      aiContext: `This is a user-created public LearnFeed lesson about ${payload.subject}.`,
    };
    try {
      const result = await api.video.publish(session?.id, payload);
      const savedVideo = normalizeLearnFeedVideo(result?.data?.video || localVideo);
      setVideos(prev => [savedVideo, ...prev]);
      setTab('feed');
      open('video', savedVideo);
      return;
    } catch (error) {
      showToast('Saved locally', error.message || 'Backend publish failed, so this lesson stayed on this device.');
    }
    setVideos(prev => [localVideo, ...prev]);
    setTab('feed');
    open('video', localVideo);
  }
  async function startHostedLive(payload) {
    const localRoom = {
      id: `live-${Date.now()}`,
      host: session?.displayName || 'Teacher Creator',
      handle: session?.handle || '@publiccreator',
      title: payload.title || 'Live Lesson',
      subject: payload.subject || 'General',
      viewers: 1,
      avatar: session?.role === 'teacher' ? '👨🏾‍🏫' : '🎓',
      emoji: payload.emoji || '🔴',
      mine: true,
    };
    try {
      const result = await api.live.start(session?.id, payload);
      const room = result?.data?.room || localRoom;
      setLiveRooms(prev => [room, ...prev]);
      open('liveRoom', room);
      return;
    } catch (error) {
      showToast('Live saved locally', error.message || 'Backend live start failed.');
    }
    setLiveRooms(prev => [localRoom, ...prev]);
    open('liveRoom', localRoom);
  }


  if (!session) {
    return <Shell><LoginScreen onLogin={(payload) => { setSession(payload); setTab('feed'); }} /></Shell>;
  }

  if (screen?.type === 'video') return <Shell><VideoScreen video={screen.data} onBack={close} open={open} patchVideo={patchVideo} routeTab={routeTab} /></Shell>;
  if (screen?.type === 'comments') return <Shell><CommentsScreen video={screen.data} onBack={close} patchVideo={patchVideo} session={session} /></Shell>;
  if (screen?.type === 'share') return <Shell><ShareSheet video={screen.data} onBack={close} patchVideo={patchVideo} /></Shell>;
  if (screen?.type === 'ai') return <Shell><AITutorScreen video={screen.data} onBack={close} /></Shell>;
  if (screen?.type === 'quiz') return <Shell><QuizScreen video={screen.data} onBack={close} open={open} /></Shell>;
  if (screen?.type === 'sounds') return <Shell><SoundLibraryScreen onBack={close} onPick={(sound) => open('create', { sound })} /></Shell>;
  if (screen?.type === 'effects') return <Shell><EffectsScreen onBack={close} /></Shell>;
  if (screen?.type === 'remix') return <Shell><RemixScreen video={screen.data} onBack={close} open={open} /></Shell>;
  if (screen?.type === 'report') return <Shell><ReportScreen video={screen.data} onBack={close} /></Shell>;
  if (screen?.type === 'liveRoom') return <Shell><LiveRoomScreen room={screen.data} onBack={close} /></Shell>;
  if (screen?.type === 'hostLive') return <Shell><HostLiveScreen onBack={close} onStart={startHostedLive} /></Shell>;
  if (screen?.type === 'creatorStudio') return <Shell><CreatorStudioScreen onBack={close} videos={videos} open={open} /></Shell>;
  if (screen?.type === 'wallet') return <Shell><WalletScreen onBack={close} session={session} /></Shell>;
  if (screen?.type === 'subscription') return <Shell><SubscriptionScreen onBack={close} session={session} /></Shell>;
  if (screen?.type === 'settings') return <Shell><SettingsScreen onBack={close} session={session} setSession={setSession} /></Shell>;
  if (screen?.type === 'notifications') return <Shell><NotificationsScreen onBack={close} open={open} routeTab={routeTab} videos={videos} /></Shell>;
  if (screen?.type === 'create') return <Shell><CreateScreen onBack={close} session={session} onPublish={publishVideo} open={open} starter={screen.data} /></Shell>;

  return (
    <Shell>
      {tab === 'feed' && <FeedScreen videos={videos} activeFeed={activeFeed} setActiveFeed={setActiveFeed} open={open} patchVideo={patchVideo} routeTab={routeTab} liveRooms={liveRooms} session={session} />}
      {tab === 'discover' && <DiscoverScreen videos={videos} liveRooms={liveRooms} open={open} routeTab={routeTab} />}
      {tab === 'create' && <CreateScreen onBack={() => routeTab('feed')} session={session} onPublish={publishVideo} open={open} />}
      {tab === 'inbox' && <InboxScreen open={open} />}
      {tab === 'profile' && <ProfileScreen session={session} open={open} onLogout={() => setSession(null)} videos={videos} />}
      {tab === 'feed' && <Pressable style={styles.floatingBell} onPress={() => open('notifications')}><Ionicons name="notifications" color="#fff" size={20} /><View style={styles.bellDot} /></Pressable>}
      <BottomTabs active={tab} onChange={routeTab} />
    </Shell>
  );
}

function Shell({ children }) {
  return (
    <View style={styles.shell}>
      <StatusBar style="light" />
      {children}
    </View>
  );
}

function LoginScreen({ onLogin }) {
  const [mode, setMode] = useState('signin');
  const [role, setRole] = useState('student');
  const [email, setEmail] = useState('');
  const [platformId, setPlatformId] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  async function submit() {
    const finalEmail = email.trim().toLowerCase();
    const finalPlatformId = platformId.trim().toUpperCase();
    const finalName = displayName.trim() || finalEmail.split('@')[0] || finalPlatformId;
    if (!finalPlatformId && !finalEmail) return showToast('Account needed', 'Enter your email or your ShuleAI Elimu ID.');
    if (!password.trim()) return showToast('Password needed', 'Enter your password to continue.');
    try {
      setLoading(true);
      const result = finalPlatformId
        ? (mode === 'signup'
          ? await api.auth.register({ elimuid: finalPlatformId, password, platformPassword: password, role: 'student', email: finalEmail || undefined, displayName: finalName })
          : await api.auth.login(finalPlatformId, password, 'student', { elimuid: finalPlatformId }))
        : (mode === 'signup'
          ? await api.auth.register({ email: finalEmail, password, role, displayName: finalName })
          : await api.auth.login(finalEmail, password, role));
      const user = result?.data?.user || {};
      onLogin({
        ...user,
        token: result?.data?.token,
        role: user.role || role,
        email: user.email || finalEmail,
        displayName: user.displayName || finalName,
        handle: user.handle || `@${finalName.replace(/\s+/g, '').toLowerCase()}`,
        accountScope: user.accountScope || (user.isSchoolLinked ? 'school_linked' : 'individual'),
        accessType: 'public',
        isSchoolLinked: !!user.isSchoolLinked,
        paymentScope: user.paymentScope || (user.isSchoolLinked ? 'existing_school_subscription' : 'user'),
        subscriptionStatus: user.subscriptionStatus || 'free',
        subscriptionPlanCode: user.subscriptionPlanCode || 'free',
        subscriptionEndsAt: user.subscriptionEndsAt || null,
        accessActive: !!user.accessActive,
        learnFeedId: user.learnFeedId,
      });
    } catch (error) {
      showToast(mode === 'signup' ? 'Signup failed' : 'Login failed', error.message || 'Check the backend and try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView style={styles.loginPage} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={styles.glowTop} />
      <View style={styles.glowBot} />
      <ScrollView contentContainerStyle={styles.loginScroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <View style={styles.logoBlock}>
          <View style={styles.logoCircle}><Ionicons name="school" color="#fff" size={42} /></View>
          <Text style={styles.logoName}>Shule AI</Text>
          <Text style={styles.logoSub}>LEARNFEED</Text>
        </View>

        <View style={styles.cardXL}>
          <View style={styles.segmentRow}>
            {['signin', 'signup'].map(x => <Pill key={x} label={x === 'signin' ? 'Sign in' : 'Create account'} active={mode === x} onPress={() => setMode(x)} />)}
          </View>
          <Text style={styles.cardTitle}>{mode === 'signin' ? 'Welcome back' : 'Join LearnFeed'}</Text>
          <Text style={styles.cardSub}>Use email for a public account, or Elimu ID if your school already uses ShuleAI.</Text>

          <View style={styles.publicBanner}>
            <Ionicons name="link-outline" color={colors.teal} size={20} />
            <Text style={styles.publicBannerText}>Linked ShuleAI students keep their existing subscription access.</Text>
          </View>

          {!platformId.trim() && <><Text style={styles.label}>Role</Text><View style={styles.roleRow}>
            <RolePill icon="🎓" title="Student" active={role === 'student'} onPress={() => setRole('student')} />
            <RolePill icon="👨🏾‍🏫" title="Teacher / Creator" active={role === 'teacher'} onPress={() => setRole('teacher')} />
          </View></>}

          {mode === 'signup' && !platformId.trim() && <Field label="Display name" value={displayName} onChangeText={setDisplayName} placeholder="e.g. Brian Otieno" />}
          <Field label="Email" value={email} onChangeText={setEmail} placeholder="your@email.com" keyboardType="email-address" />
          <Field label="Elimu ID" value={platformId} onChangeText={setPlatformId} placeholder="Optional: ELI-2026-2058" autoCapitalize="characters" />
          <Text style={styles.label}>Password</Text>
          <View style={styles.passWrap}>
            <TextInput style={[styles.input, { flex: 1, marginBottom: 0 }]} value={password} onChangeText={setPassword} secureTextEntry={!showPass} placeholder="password" placeholderTextColor={colors.textMuted} />
            <Pressable onPress={() => setShowPass(v => !v)} style={styles.eyeBtn}><Ionicons name={showPass ? 'eye-off' : 'eye'} color={colors.textSub} size={20} /></Pressable>
          </View>

          <Pressable style={[styles.primaryBtn, loading && { opacity: 0.7 }]} onPress={loading ? undefined : submit}>
            <Text style={styles.primaryBtnText}>{loading ? 'Connecting...' : 'Enter LearnFeed'}</Text>
            <Ionicons name="arrow-forward" color="#fff" size={18} />
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}


function FeedScreen({ videos, activeFeed, setActiveFeed, open, patchVideo, routeTab, liveRooms, session }) {
  const filteredVideos = useMemo(() => {
    if (activeFeed === 'Following') return videos.filter(v => v.following || v.verified);
    if (activeFeed === 'Live') return videos.filter(v => v.live);
    if (activeFeed === 'STEM') return videos.filter(v => ['CHEMISTRY', 'MATHEMATICS', 'BIOLOGY', 'PHYSICS'].includes(v.subject));
    return videos;
  }, [videos, activeFeed]);

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={filteredVideos.length ? filteredVideos : videos}
        keyExtractor={item => item.id}
        pagingEnabled
        snapToInterval={FEED_H}
        decelerationRate="fast"
        showsVerticalScrollIndicator={false}
        getItemLayout={(_, index) => ({ length: FEED_H, offset: FEED_H * index, index })}
        renderItem={({ item }) => <FeedCard video={item} open={open} patchVideo={patchVideo} routeTab={routeTab} activeFeed={activeFeed} setActiveFeed={setActiveFeed} liveRooms={liveRooms} session={session} />}
      />
    </View>
  );
}

function FeedCard({ video, open, patchVideo, routeTab, activeFeed, setActiveFeed, liveRooms, session }) {
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [followed, setFollowed] = useState(video.following);

  function like() {
    setLiked(v => !v);
    patchVideo(video.id, v => ({ likes: v.likes + (liked ? -1 : 1) }));
    if (session) api.feed.like(session.id, video.id).catch(() => {});
  }
  function save() {
    setSaved(v => !v);
    patchVideo(video.id, v => ({ saves: v.saves + (saved ? -1 : 1) }));
    if (session) api.feed.save(session.id, video.id).catch(() => {});
  }
  function follow() {
    setFollowed(v => !v);
    patchVideo(video.id, { following: !followed });
    if (session) api.feed.follow(session.id, video.creatorId, video.id).catch(() => {});
    showToast(!followed ? 'Followed' : 'Unfollowed', `${video.creator}`);
  }

  return (
    <View style={[styles.feedItem, { height: FEED_H }]}>
      <View style={styles.videoLayer}>
        <View style={[styles.visualOrb, { backgroundColor: video.subject === 'CHEMISTRY' ? 'rgba(0,194,186,0.12)' : 'rgba(123,92,246,0.12)' }]} />
        <Text style={styles.videoEmoji}>{video.visualEmoji}</Text>
        <Text style={styles.bgFormula}>{video.subject === 'CHEMISTRY' ? 'M₁V₁ = M₂V₂' : video.subject === 'MATHEMATICS' ? 'ax² + bx + c = 0' : video.subject === 'PHYSICS' ? 'F = ma' : 'CO₂ + H₂O → O₂'}</Text>
      </View>

      <View style={styles.feedTop}>
        <View style={styles.feedTopLeft}>
          <View style={styles.subjectBadge}><Text style={styles.subjectText}>{video.subject}</Text></View>
          <View style={styles.classBadge}><Text style={styles.classText}>{video.className}</Text></View>
        </View>
        <Pressable onPress={() => routeTab('discover')} hitSlop={12}><Ionicons name="search" color="#fff" size={23} /></Pressable>
      </View>

      <View style={styles.feedTabsRow}>
        {['For You', 'Following', 'STEM', 'Live'].map(tab => (
          <Pressable key={tab} onPress={() => tab === 'Live' && liveRooms?.length ? open('liveRoom', liveRooms[0]) : setActiveFeed(tab)}>
            <Text style={[styles.feedTab, activeFeed === tab && styles.feedTabActive]}>{tab}</Text>
          </Pressable>
        ))}
      </View>

      {video.live && <Pressable style={styles.liveBadge} onPress={() => open('liveRoom', liveRooms?.[0])}><View style={styles.liveDot} /><Text style={styles.liveBadgeText}>LIVE</Text></Pressable>}

      <View style={styles.actionRail}>
        <View style={styles.avatarWrap}>
          <Pressable onPress={() => routeTab('profile')} style={styles.railAvatar}><Text style={styles.avatarEmoji}>{video.avatar}</Text></Pressable>
          <Pressable style={styles.followMini} onPress={follow}><Ionicons name={followed ? 'checkmark' : 'add'} color="#fff" size={14} /></Pressable>
        </View>
        <RailButton icon={liked ? 'heart' : 'heart-outline'} color={liked ? colors.pink : '#fff'} label={formatCount(video.likes + (liked ? 1 : 0))} onPress={like} />
        <RailButton icon="chatbubble-ellipses" label={formatCount(video.comments)} onPress={() => open('comments', video)} />
        <RailButton icon={saved ? 'bookmark' : 'bookmark-outline'} color={saved ? colors.teal : '#fff'} label={formatCount(video.saves + (saved ? 1 : 0))} onPress={save} />
        <RailButton icon="arrow-redo" label={formatCount(video.shares)} onPress={() => open('share', video)} />
        <RailButton icon="git-compare-outline" label="Remix" onPress={() => open('remix', video)} />
        <Pressable style={styles.soundDisc} onPress={() => open('sounds')}><Ionicons name="musical-notes" color="#fff" size={18} /></Pressable>
      </View>

      <View style={styles.bottomInfo}>
        <Pressable style={styles.creatorRow} onPress={() => routeTab('profile')}>
          <Text style={styles.creatorAvatar}>{video.avatar}</Text>
          <View style={{ flex: 1 }}>
            <View style={styles.creatorNameRow}><Text style={styles.creatorName}>{video.creator}</Text>{video.verified && <Ionicons name="checkmark-circle" color={colors.teal} size={16} />}</View>
            <Text style={styles.creatorRole}>{video.role} · {video.handle}</Text>
          </View>
          <Pressable style={[styles.followBtn, followed && styles.followingBtn]} onPress={follow}><Text style={styles.followBtnText}>{followed ? 'Following' : 'Follow'}</Text></Pressable>
        </Pressable>
        <Pressable onPress={() => open('video', video)}>
          <Text style={styles.clipTitle}>{video.title}</Text>
          <Text style={styles.clipDesc} numberOfLines={2}>{video.description}</Text>
        </Pressable>
        <Pressable style={styles.soundRow} onPress={() => open('sounds')}><Ionicons name="musical-note" color="#fff" size={14} /><Text style={styles.soundText}>{video.sound}</Text></Pressable>
        <View style={styles.quickBtns}>
          <Pressable style={styles.aiBtn} onPress={() => open('ai', video)}><Ionicons name="sparkles" color={colors.teal} size={16} /><Text style={styles.aiBtnText}>Ask AI</Text></Pressable>
          <Pressable style={styles.quizBtn} onPress={() => open('quiz', video)}><Ionicons name="school" color="#fff" size={16} /><Text style={styles.quizBtnText}>Take Quiz</Text></Pressable>
          <Pressable style={styles.darkBtn} onPress={() => routeTab('create')}><Ionicons name="add-circle-outline" color="#fff" size={16} /><Text style={styles.darkBtnText}>Create</Text></Pressable>
        </View>
      </View>
    </View>
  );
}

function DiscoverScreen({ videos, liveRooms, open, routeTab }) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All');
  const filters = ['All', 'Trending', 'Live', 'Sounds', 'Effects', 'STEM', 'Following'];
  const results = videos.filter(v => {
    const q = query.trim().toLowerCase();
    const matchesQuery = !q || `${v.title} ${v.subject} ${v.creator} ${v.topic}`.toLowerCase().includes(q);
    const matchesFilter = filter === 'All' || filter === 'Trending' || (filter === 'Live' ? v.live : filter === 'STEM' ? ['CHEMISTRY', 'MATHEMATICS', 'BIOLOGY', 'PHYSICS'].includes(v.subject) : filter === 'Following' ? v.following : true);
    return matchesQuery && matchesFilter;
  });

  return (
    <View style={styles.pageWithNav}>
      <View style={styles.searchHeader}>
        <View style={styles.searchBar}><Ionicons name="search" color={colors.textMuted} size={18} /><TextInput value={query} onChangeText={setQuery} placeholder="Search lessons, creators, sounds..." placeholderTextColor={colors.textMuted} style={styles.searchInput} />{query ? <Pressable onPress={() => setQuery('')}><Ionicons name="close-circle" color={colors.textMuted} size={18} /></Pressable> : null}</View>
      </View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100 }}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontalPills}>
          {filters.map(f => <Pill key={f} label={f} active={filter === f} onPress={() => { setFilter(f); if (f === 'Sounds') open('sounds'); if (f === 'Effects') open('effects'); }} />)}
        </ScrollView>
        <SectionTitle title="LIVE NOW" action="See all" onPress={() => open('liveRoom', liveRooms[0])} />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 14, gap: 10, marginBottom: 18 }}>
          {liveRooms.map(room => <Pressable key={room.id} style={styles.liveCard} onPress={() => open('liveRoom', room)}><Text style={styles.liveCardEmoji}>{room.emoji}</Text><View style={styles.livePill}><Text style={styles.livePillText}>LIVE</Text></View><Text style={styles.liveCardTitle} numberOfLines={2}>{room.title}</Text><Text style={styles.liveCardSub}>{formatCount(room.viewers)} watching</Text></Pressable>)}
        </ScrollView>
        <SectionTitle title="TRENDING LESSONS" action="Create" onPress={() => routeTab('create')} />
        <View style={styles.gridWrap}>
          {results.map(item => <Pressable key={item.id} style={styles.discoverCard} onPress={() => open('video', item)}><View style={styles.discoverBg}><Text style={styles.discoverEmoji}>{item.visualEmoji}</Text><View style={styles.discoverOverlay}><Text style={styles.discoverTitle} numberOfLines={2}>{item.title}</Text><View style={styles.miniMeta}><Ionicons name="play" color="rgba(255,255,255,0.7)" size={11} /><Text style={styles.miniMetaText}>{item.views}</Text></View></View></View></Pressable>)}
        </View>
      </ScrollView>
    </View>
  );
}

function CreateScreen({ session, onBack, onPublish, open, starter }) {
  const [mode, setMode] = useState('Record');
  const [recording, setRecording] = useState(false);
  const [clipReady, setClipReady] = useState(!!starter);
  const [caption, setCaption] = useState('');
  const [description, setDescription] = useState('');
  const [subject, setSubject] = useState('Chemistry');
  const [className, setClassName] = useState('Form 3');
  const [sound, setSound] = useState(starter?.sound?.title || 'Original Sound');
  const [visibility, setVisibility] = useState('Public');
  const [allowComments, setAllowComments] = useState(true);
  const [allowDuet, setAllowDuet] = useState(true);
  const [allowStitch, setAllowStitch] = useState(true);
  const [effect, setEffect] = useState('Auto Captions');

  function finishRecording() {
    setRecording(false);
    setClipReady(true);
    setMode('Edit');
  }
  function publish() {
    if (!caption.trim()) return showToast('Caption needed', 'Add a title/caption before publishing.');
    onPublish({ caption, description, subject, className, sound, visibility, allowComments, allowDuet, allowStitch, effect, emoji: subject === 'Chemistry' ? '🧪' : subject === 'Mathematics' ? '📐' : subject === 'Physics' ? '⚙️' : '🎓' });
  }

  return (
    <View style={styles.page}>
      <TopBar title="Creator Studio" onBack={onBack} right={<Pressable onPress={() => open('hostLive')} style={styles.headerPill}><Ionicons name="radio" color={colors.pink} size={14} /><Text style={styles.headerPillText}>Go Live</Text></Pressable>} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, paddingBottom: 60 }}>
        <View style={styles.segmentRow}>{['Record', 'Upload', 'Edit', 'Post'].map(x => <Pill key={x} label={x} active={mode === x} onPress={() => setMode(x)} />)}</View>

        {mode === 'Record' && <View style={styles.cameraPanel}><View style={styles.cameraTop}><Text style={styles.recText}>{recording ? '● REC 00:12' : 'Ready to record'}</Text><Text style={styles.cameraQuality}>1080p</Text></View><Text style={styles.cameraEmoji}>{clipReady ? '✅' : '📹'}</Text><Text style={styles.cameraHint}>Frontend studio: record controls, effects, sound, speed, timer, captions and live flow.</Text><View style={styles.cameraTools}>{['Flip', 'Speed', 'Timer', 'Beauty', 'Captions', 'Green'].map((tool, i) => <Pressable key={tool} style={styles.cameraTool} onPress={() => showToast(tool, `${tool} tool opened.`)}><Ionicons name={['camera-reverse','speedometer','timer','sparkles','text','albums'][i]} color="#fff" size={20} /><Text style={styles.cameraToolText}>{tool}</Text></Pressable>)}</View><Pressable style={[styles.recordBtn, recording && styles.recordingBtn]} onPress={() => recording ? finishRecording() : setRecording(true)}><View style={styles.recordInner} /></Pressable><Text style={styles.smallMuted}>{recording ? 'Tap again to stop and edit' : 'Tap red button to start recording'}</Text></View>}

        {mode === 'Upload' && <View style={styles.bigActionCard}><Ionicons name="cloud-upload-outline" color={colors.teal} size={42} /><Text style={styles.bigActionTitle}>Upload video</Text><Text style={styles.bigActionSub}>Connect this button to a media picker in the native/live build. The frontend flow is ready.</Text><Pressable style={styles.primaryBtn} onPress={() => { setClipReady(true); setMode('Edit'); }}><Text style={styles.primaryBtnText}>Use Uploaded Demo Clip</Text><Ionicons name="checkmark" color="#fff" size={18} /></Pressable></View>}

        {mode === 'Edit' && <View><View style={styles.previewCard}><Text style={styles.previewEmoji}>{clipReady ? '🎬' : '📹'}</Text><Text style={styles.previewTitle}>{clipReady ? 'Clip ready for editing' : 'Record or upload first'}</Text></View><SectionTitle title="EDIT TOOLS" /><View style={styles.toolGrid}>{effectLibrary.map(e => <Pressable key={e.id} style={[styles.toolTile, effect === e.name && { borderColor: e.color }]} onPress={() => setEffect(e.name)}><Ionicons name={e.icon} color={e.color} size={24} /><Text style={styles.toolTileText}>{e.name}</Text></Pressable>)}</View><Pressable style={styles.optionRow} onPress={() => open('sounds')}><Ionicons name="musical-notes" color={colors.teal} size={20} /><Text style={styles.optionRowText}>Sound: {sound}</Text><Ionicons name="chevron-forward" color={colors.textMuted} size={18} /></Pressable><Pressable style={styles.primaryBtn} onPress={() => setMode('Post')}><Text style={styles.primaryBtnText}>Next: Post Details</Text><Ionicons name="arrow-forward" color="#fff" size={18} /></Pressable></View>}

        {mode === 'Post' && <View><Field label="Caption / title" value={caption} onChangeText={setCaption} placeholder="e.g. Titration Explained" /><Field label="Description" value={description} onChangeText={setDescription} placeholder="What will learners understand?" multiline /><PickerRow label="Subject" value={subject} options={['Chemistry','Mathematics','Biology','Physics','English','Kiswahili']} onChange={setSubject} /><PickerRow label="Class" value={className} options={['Form 1','Form 2','Form 3','Form 4','Grade 7','Grade 8','Public']} onChange={setClassName} /><PickerRow label="Visibility" value={visibility} options={['Public','Followers','Private']} onChange={setVisibility} /><ToggleRow label="Allow comments" value={allowComments} onChange={setAllowComments} /><ToggleRow label="Allow Duet" value={allowDuet} onChange={setAllowDuet} /><ToggleRow label="Allow Stitch" value={allowStitch} onChange={setAllowStitch} /><Pressable style={styles.primaryBtn} onPress={publish}><Text style={styles.primaryBtnText}>Publish to LearnFeed</Text><Ionicons name="rocket" color="#fff" size={18} /></Pressable></View>}
      </ScrollView>
    </View>
  );
}

function InboxScreen({ open }) {
  const [selected, setSelected] = useState(null);
  const [messages, setMessages] = useState(initialMessages);
  const [thread, setThread] = useState([
    { id: 't1', from: 'them', text: 'Can you send the titration notes?', time: '2:30 PM' },
    { id: 't2', from: 'me', text: 'Yes, check the lesson attachments.', time: '2:31 PM' },
  ]);
  const [text, setText] = useState('');

  if (selected) {
    return <View style={styles.pageWithNav}><TopBar title={selected.name} onBack={() => setSelected(null)} right={<Pressable onPress={() => showToast('Call', 'Audio/video call UI opened.')}><Ionicons name="call-outline" color={colors.teal} size={22} /></Pressable>} /><FlatList data={thread} keyExtractor={i => i.id} contentContainerStyle={{ padding: 16, paddingBottom: 110 }} renderItem={({ item }) => <View style={[styles.bubble, item.from === 'me' ? styles.myBubble : styles.theirBubble]}><Text style={styles.bubbleText}>{item.text}</Text><Text style={styles.bubbleTime}>{item.time}</Text></View>} /><View style={styles.chatInputBar}><TextInput style={styles.chatInput} value={text} onChangeText={setText} placeholder="Send a message..." placeholderTextColor={colors.textMuted} /><Pressable onPress={() => showToast('Attach', 'Attachment picker opened.')}><Ionicons name="attach" color={colors.textSub} size={22} /></Pressable><Pressable style={styles.sendBtn} onPress={() => { if (text.trim()) { setThread(p => [...p, { id: `${Date.now()}`, from: 'me', text: text.trim(), time: 'now' }]); setText(''); } }}><Ionicons name="send" color="#fff" size={18} /></Pressable></View></View>;
  }

  return (
    <View style={styles.pageWithNav}>
      <View style={styles.screenHeader}><Text style={styles.screenTitle}>Inbox</Text><Pressable onPress={() => open('notifications')}><Ionicons name="notifications-outline" color={colors.teal} size={24} /></Pressable></View>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 110 }} showsVerticalScrollIndicator={false}>
        <View style={styles.inboxQuickRow}>{['Activity','Requests','Live invites','System'].map(x => <Pressable key={x} style={styles.inboxQuick} onPress={() => showToast(x, `${x} opened.`)}><Text style={styles.inboxQuickText}>{x}</Text></Pressable>)}</View>
        {messages.map(m => <Pressable key={m.id} style={styles.messageRow} onPress={() => { setSelected(m); setMessages(prev => prev.map(x => x.id === m.id ? { ...x, unread: 0 } : x)); }}><View style={styles.msgAvatarWrap}><Text style={styles.msgAvatar}>{m.avatar}</Text>{m.online && <View style={styles.onlineDot} />}</View><View style={{ flex: 1 }}><Text style={styles.msgName}>{m.name}</Text><Text style={styles.msgLast}>{m.last}</Text></View>{m.unread > 0 && <View style={styles.unreadBadge}><Text style={styles.unreadText}>{m.unread}</Text></View>}</Pressable>)}
      </ScrollView>
    </View>
  );
}

function ProfileScreen({ session, open, onLogout, videos }) {
  const myVideos = videos.filter(v => v.creator.toLowerCase().includes((session.displayName || '').toLowerCase().split(' ')[0]) || v.id.startsWith('user')).slice(0, 6);
  return (
    <ScrollView style={styles.pageWithNav} contentContainerStyle={{ paddingBottom: 110 }} showsVerticalScrollIndicator={false}>
      <View style={styles.profileTop}>
        <View style={styles.profileHeaderRow}><View style={styles.bigAvatar}><Text style={styles.bigAvatarText}>{session.role === 'teacher' ? '👨🏾‍🏫' : '🎓'}</Text></View><View style={{ flex: 1 }}><View style={styles.creatorNameRow}><Text style={styles.profileName}>{session.displayName}</Text>{session.role === 'teacher' && <Ionicons name="checkmark-circle" color={colors.teal} size={18} />}</View><Text style={styles.profileHandle}>{session.handle} · {session.role === 'teacher' ? 'Teacher / Creator' : 'Student'}</Text></View><Pressable onPress={() => open('settings')}><Ionicons name="settings-outline" color="#fff" size={24} /></Pressable></View>
        <View style={styles.statsRow}><Stat value="128" label="Following" /><Divider /><Stat value="2.4K" label="Followers" /><Divider /><Stat value="56.7K" label="Likes" /></View>
        <Text style={styles.profileBio}>Public LearnFeed account. Learn, create, go live, and grow your audience.</Text>
        <View style={styles.profileBtns}><Pressable style={styles.editProfileBtn} onPress={() => open('settings')}><Text style={styles.editProfileText}>Edit Profile</Text></Pressable><Pressable style={styles.iconSquare} onPress={() => Share.share({ message: `Follow ${session.handle} on LearnFeed` })}><Ionicons name="share-social-outline" color="#fff" size={20} /></Pressable></View>
      </View>

      <View style={styles.creatorToolsGrid}>
        <ToolButton icon="bar-chart-outline" label="Creator Studio" onPress={() => open('creatorStudio')} />
        <ToolButton icon="wallet-outline" label="Wallet" onPress={() => open('wallet')} />
        <ToolButton icon="card-outline" label="Subscription" onPress={() => open('subscription')} />
        <ToolButton icon="radio-outline" label="Go Live" onPress={() => open('hostLive')} />
      </View>

      <SectionTitle title="VIDEOS" action="Create" onPress={() => open('create')} />
      <View style={styles.profileGrid}>{(myVideos.length ? myVideos : videos.slice(0, 6)).map(v => <Pressable key={v.id} style={styles.profileVideo} onPress={() => open('video', v)}><Text style={styles.profileVideoEmoji}>{v.visualEmoji}</Text><View style={styles.profileVideoMeta}><Ionicons name="play" color="#fff" size={12} /><Text style={styles.profileVideoViews}>{v.views}</Text></View></Pressable>)}</View>
      <Pressable style={styles.logoutBtn} onPress={onLogout}><Ionicons name="log-out-outline" color={colors.danger} size={18} /><Text style={styles.logoutText}>Sign Out</Text></Pressable>
    </ScrollView>
  );
}

function VideoScreen({ video, onBack, open, patchVideo, routeTab }) {
  return <View style={styles.page}><TopBar title="Video" onBack={onBack} right={<Pressable onPress={() => open('report', video)}><Ionicons name="flag-outline" color={colors.textSub} size={22} /></Pressable>} /><View style={{ flex: 1 }}><FeedCard video={video} open={open} patchVideo={patchVideo} routeTab={routeTab} activeFeed="For You" setActiveFeed={() => {}} liveRooms={liveRoomsSeed} /></View></View>;
}

function CommentsScreen({ video, onBack, patchVideo, session }) {
  const [text, setText] = useState('');
  const [comments, setComments] = useState([
    { id: 'c1', user: 'Miss Amina', avatar: '👩🏾‍🏫', text: 'Great explanation. This is clear for revision.', likes: 58, pinned: true },
    { id: 'c2', user: 'Kevin', avatar: '👦🏾', text: 'Can you explain the endpoint again?', likes: 12 },
    { id: 'c3', user: 'Grace', avatar: '👧🏾', text: 'This helped me understand better 🔥', likes: 8 },
  ]);
  useEffect(() => {
    let alive = true;
    api.comments.list(video.id).then((result) => {
      const next = result?.data?.comments || [];
      if (alive && Array.isArray(next) && next.length) setComments(next);
    }).catch(() => {});
    return () => { alive = false; };
  }, [video.id]);
  async function send() {
    if (!text.trim()) return;
    const value = text.trim();
    setText('');
    try {
      const result = await api.comments.add(session?.id, video.id, value);
      const savedComment = result?.data?.comment || { id: `${Date.now()}`, user: 'You', avatar: '🙂', text: value, likes: 0 };
      setComments(p => [savedComment, ...p]);
    } catch (error) {
      setComments(p => [{ id: `${Date.now()}`, user: 'You', avatar: '🙂', text: value, likes: 0 }, ...p]);
    }
    patchVideo(video.id, v => ({ comments: v.comments + 1 }));
  }
  return <View style={styles.page}><TopBar title={`Comments (${formatCount(video.comments)})`} onBack={onBack} /><FlatList data={comments} keyExtractor={i => String(i.id)} contentContainerStyle={{ padding: 16, paddingBottom: 96 }} renderItem={({ item }) => <View style={styles.commentRow}><Text style={styles.commentAvatar}>{item.avatar}</Text><View style={{ flex: 1 }}><View style={styles.creatorNameRow}><Text style={styles.commentName}>{item.user}</Text>{item.pinned && <View style={styles.pinPill}><Text style={styles.pinText}>PINNED</Text></View>}</View><Text style={styles.commentText}>{item.text}</Text><View style={styles.commentActions}><Text style={styles.commentAction}>Reply</Text><Text style={styles.commentAction}>{item.likes} likes</Text></View></View><Pressable onPress={() => showToast('Liked', 'Comment liked.')}><Ionicons name="heart-outline" color={colors.textSub} size={20} /></Pressable></View>} /><View style={styles.chatInputBar}><TextInput style={styles.chatInput} value={text} onChangeText={setText} placeholder="Add comment..." placeholderTextColor={colors.textMuted} /><Pressable style={styles.sendBtn} onPress={send}><Ionicons name="send" color="#fff" size={18} /></Pressable></View></View>;
}


function ShareSheet({ video, onBack, patchVideo }) {
  const actions = [
    ['Copy Link', 'link-outline'], ['WhatsApp', 'logo-whatsapp'], ['Messages', 'chatbubble-outline'], ['Save Video', 'download-outline'], ['Add to Story', 'add-circle-outline'], ['Not Interested', 'eye-off-outline'], ['Report', 'flag-outline'], ['QR Code', 'qr-code-outline'],
  ];
  async function shareNative() {
    patchVideo(video.id, v => ({ shares: v.shares + 1 }));
    try { await Share.share({ message: `${video.title} on Shule AI LearnFeed` }); } catch (e) { showToast('Share', 'Share opened.'); }
  }
  return <View style={styles.page}><TopBar title="Share" onBack={onBack} /><View style={{ padding: 16 }}><View style={styles.sharePreview}><Text style={styles.shareEmoji}>{video.visualEmoji}</Text><View style={{ flex: 1 }}><Text style={styles.shareTitle}>{video.title}</Text><Text style={styles.shareSub}>by {video.creator}</Text></View></View><View style={styles.shareGrid}>{actions.map(([label, icon]) => <Pressable key={label} style={styles.shareAction} onPress={() => label === 'Copy Link' || label === 'WhatsApp' || label === 'Messages' ? shareNative() : showToast(label, `${label} action completed.`)}><View style={styles.shareIcon}><Ionicons name={icon} color="#fff" size={22} /></View><Text style={styles.shareActionText}>{label}</Text></Pressable>)}</View></View></View>;
}

function AITutorScreen({ video, onBack }) {
  const [text, setText] = useState('');
  const [chat, setChat] = useState([{ id: 'a1', from: 'ai', text: `Ask me anything about ${video.title}.` }]);
  function ask() { if (!text.trim()) return; const q = text.trim(); setChat(p => [...p, { id: `${Date.now()}u`, from: 'me', text: q }, { id: `${Date.now()}a`, from: 'ai', text: `${video.aiContext} For your question: "${q}", start by identifying the key concept, then solve step by step.` }]); setText(''); }
  return <View style={styles.page}><TopBar title="AI Tutor" onBack={onBack} /><FlatList data={chat} keyExtractor={i => i.id} contentContainerStyle={{ padding: 16, paddingBottom: 96 }} renderItem={({ item }) => <View style={[styles.bubble, item.from === 'me' ? styles.myBubble : styles.aiBubble]}><Text style={styles.bubbleText}>{item.text}</Text></View>} /><View style={styles.chatInputBar}><TextInput style={styles.chatInput} value={text} onChangeText={setText} placeholder="Ask AI Tutor..." placeholderTextColor={colors.textMuted} /><Pressable style={styles.sendBtn} onPress={ask}><Ionicons name="send" color="#fff" size={18} /></Pressable></View></View>;
}

function QuizScreen({ video, onBack, open }) {
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const correct = selected === video.answer;
  return <View style={styles.page}><TopBar title="Quiz" onBack={onBack} right={<Pressable onPress={() => open('ai', video)}><Ionicons name="sparkles" color={colors.teal} size={22} /></Pressable>} /><View style={{ padding: 16 }}><Text style={styles.quizTopic}>{video.topic}</Text><Text style={styles.quizQuestion}>{video.question}</Text>{video.options.map((opt, idx) => <Pressable key={opt} style={[styles.quizOption, selected === idx && styles.quizSelected, submitted && idx === video.answer && styles.quizCorrect, submitted && selected === idx && selected !== video.answer && styles.quizWrong]} onPress={() => !submitted && setSelected(idx)}><Text style={styles.quizOptionText}>{opt}</Text>{submitted && idx === video.answer && <Ionicons name="checkmark-circle" color={colors.green} size={20} />}</Pressable>)}{submitted ? <View style={styles.resultCard}><Text style={styles.resultTitle}>{correct ? 'Correct! +50 XP' : 'Not yet. Try reviewing with AI.'}</Text><Text style={styles.resultSub}>{correct ? 'You understood the key lesson.' : video.aiContext}</Text></View> : <Pressable style={styles.primaryBtn} onPress={() => selected === null ? showToast('Pick an answer') : setSubmitted(true)}><Text style={styles.primaryBtnText}>Submit Answer</Text><Ionicons name="checkmark" color="#fff" size={18} /></Pressable>}</View></View>;
}

function SoundLibraryScreen({ onBack, onPick }) {
  return <View style={styles.page}><TopBar title="Sounds" onBack={onBack} /><ScrollView contentContainerStyle={{ padding: 16 }}>{soundLibrary.map(s => <Pressable key={s.id} style={styles.soundItem} onPress={() => onPick ? onPick(s) : showToast('Sound selected', s.title)}><View style={styles.soundIcon}><Ionicons name={s.icon} color={colors.teal} size={22} /></View><View style={{ flex: 1 }}><Text style={styles.soundItemTitle}>{s.title}</Text><Text style={styles.soundItemSub}>{s.creator} · {s.uses} uses</Text></View><Ionicons name="play-circle" color="#fff" size={30} /></Pressable>)}</ScrollView></View>;
}

function EffectsScreen({ onBack }) {
  return <View style={styles.page}><TopBar title="Effects" onBack={onBack} /><ScrollView contentContainerStyle={{ padding: 16 }}><View style={styles.toolGrid}>{effectLibrary.map(e => <Pressable key={e.id} style={styles.toolTile} onPress={() => showToast(e.name, `${e.name} applied.`)}><Ionicons name={e.icon} color={e.color} size={28} /><Text style={styles.toolTileText}>{e.name}</Text></Pressable>)}</View></ScrollView></View>;
}

function RemixScreen({ video, onBack, open }) {
  return <View style={styles.page}><TopBar title="Duet / Stitch" onBack={onBack} /><View style={{ padding: 16 }}><View style={styles.duetPreview}><View style={styles.duetHalf}><Text style={styles.previewEmoji}>{video.visualEmoji}</Text><Text style={styles.smallMuted}>Original</Text></View><View style={styles.duetHalf}><Text style={styles.previewEmoji}>🎥</Text><Text style={styles.smallMuted}>Your side</Text></View></View>{['Duet side-by-side','Stitch first 5 seconds','React with green screen','Use this sound'].map(x => <Pressable key={x} style={styles.optionRow} onPress={() => x.includes('sound') ? open('sounds') : open('create', { remix: video, mode: x })}><Ionicons name="git-compare-outline" color={colors.teal} size={20} /><Text style={styles.optionRowText}>{x}</Text><Ionicons name="chevron-forward" color={colors.textMuted} size={18} /></Pressable>)}</View></View>;
}

function LiveRoomScreen({ room, onBack }) {
  const [chat, setChat] = useState([{ id: '1', user: 'Grace', text: 'Teacher please repeat that part 🙏' }, { id: '2', user: 'Kevin', text: 'This live is helpful!' }]);
  const [msg, setMsg] = useState('');
  const [hearts, setHearts] = useState(2400);
  function send() { if (!msg.trim()) return; setChat(p => [...p, { id: `${Date.now()}`, user: 'You', text: msg.trim() }]); setMsg(''); }
  return <View style={styles.page}><View style={styles.liveStage}><View style={styles.liveTopBar}><Pressable onPress={onBack}><Ionicons name="chevron-back" color="#fff" size={26} /></Pressable><View style={styles.liveHost}><Text style={styles.liveHostAvatar}>{room.avatar}</Text><View><Text style={styles.liveHostName}>{room.host}</Text><Text style={styles.liveHostSub}>{formatCount(room.viewers)} watching</Text></View></View><View style={styles.livePill}><Text style={styles.livePillText}>LIVE</Text></View></View><Text style={styles.liveMainEmoji}>{room.emoji}</Text><Text style={styles.liveTitleBig}>{room.title}</Text><View style={styles.liveButtons}><Pressable style={styles.liveAction} onPress={() => setHearts(h => h + 1)}><Ionicons name="heart" color={colors.pink} size={22} /><Text style={styles.liveActionText}>{formatCount(hearts)}</Text></Pressable><Pressable style={styles.liveAction} onPress={() => showToast('Gift sent', 'Creator received a demo gift.')}><Ionicons name="gift" color={colors.gold} size={22} /><Text style={styles.liveActionText}>Gift</Text></Pressable><Pressable style={styles.liveAction} onPress={() => showToast('Co-host', 'Request sent to host.')}><Ionicons name="person-add" color={colors.teal} size={22} /><Text style={styles.liveActionText}>Join</Text></Pressable></View></View><FlatList data={chat} keyExtractor={i => i.id} style={styles.liveChatList} contentContainerStyle={{ padding: 12 }} renderItem={({ item }) => <Text style={styles.liveChatLine}><Text style={{ color: colors.teal, fontWeight: '900' }}>{item.user}: </Text>{item.text}</Text>} /><View style={styles.chatInputBar}><TextInput style={styles.chatInput} value={msg} onChangeText={setMsg} placeholder="Comment on live..." placeholderTextColor={colors.textMuted} /><Pressable style={styles.sendBtn} onPress={send}><Ionicons name="send" color="#fff" size={18} /></Pressable></View></View>;
}

function HostLiveScreen({ onBack, onStart }) {
  const [title, setTitle] = useState('Live: Exam Revision');
  const [subject, setSubject] = useState('Chemistry');
  return <View style={styles.page}><TopBar title="Go Live" onBack={onBack} /><ScrollView contentContainerStyle={{ padding: 16 }}><View style={styles.cameraPanel}><Text style={styles.cameraEmoji}>🔴</Text><Text style={styles.cameraHint}>Start a public LearnFeed live lesson with chat, gifts, hearts, and join requests.</Text></View><Field label="Live title" value={title} onChangeText={setTitle} /><PickerRow label="Subject" value={subject} options={['Chemistry','Mathematics','Biology','Physics','English','General']} onChange={setSubject} /><ToggleRow label="Allow gifts" value={true} onChange={() => {}} /><ToggleRow label="Allow learners to request join" value={true} onChange={() => {}} /><Pressable style={styles.primaryBtn} onPress={() => onStart({ title, subject, emoji: subject === 'Chemistry' ? '🧪' : '🔴' })}><Text style={styles.primaryBtnText}>Start Live Now</Text><Ionicons name="radio" color="#fff" size={18} /></Pressable></ScrollView></View>;
}

function CreatorStudioScreen({ onBack, videos, open }) {
  const totalLikes = videos.reduce((s, v) => s + Number(v.likes || 0), 0);
  return <View style={styles.page}><TopBar title="Creator Studio" onBack={onBack} /><ScrollView contentContainerStyle={{ padding: 16 }}><View style={styles.statsGrid}><Metric label="Views" value="356K" icon="eye-outline" color={colors.teal} /><Metric label="Likes" value={formatCount(totalLikes)} icon="heart-outline" color={colors.pink} /><Metric label="Followers" value="2.4K" icon="people-outline" color={colors.gold} /><Metric label="Revenue" value="KSh 4.8K" icon="wallet-outline" color={colors.green} /></View><SectionTitle title="TOOLS" />{['Analytics dashboard','Content calendar','Audience insights','Comment filters','Copyright center','Creator academy'].map((x, i) => <Pressable key={x} style={styles.optionRow} onPress={() => i === 0 ? showToast('Analytics', 'Analytics dashboard opened.') : showToast(x, `${x} opened.`)}><Ionicons name={['bar-chart','calendar','people','filter','shield-checkmark','school'][i]} color={colors.teal} size={20} /><Text style={styles.optionRowText}>{x}</Text><Ionicons name="chevron-forward" color={colors.textMuted} size={18} /></Pressable>)}<Pressable style={styles.primaryBtn} onPress={() => open('create')}><Text style={styles.primaryBtnText}>Create New Lesson</Text><Ionicons name="add" color="#fff" size={18} /></Pressable></ScrollView></View>;
}

function WalletScreen({ onBack, session }) {
  const [wallet, setWallet] = useState({ balanceKes: 0, currency: 'KES' });
  useEffect(() => {
    let alive = true;
    api.billing.wallet(session?.id).then((result) => {
      if (alive) setWallet(result?.data || { balanceKes: 0, currency: 'KES' });
    }).catch(() => {});
    return () => { alive = false; };
  }, [session?.id]);
  return <View style={styles.page}><TopBar title="Wallet" onBack={onBack} /><ScrollView contentContainerStyle={{ padding: 16 }}><View style={styles.walletCard}><Text style={styles.walletLabel}>Available balance</Text><Text style={styles.walletAmount}>{wallet.currency || 'KES'} {Number(wallet.balanceKes || 0).toLocaleString()}</Text><Text style={styles.walletSub}>Creator earnings from gifts, subscriptions, and bonuses.</Text></View>{['Withdraw to M-Pesa','Add payout account','Transaction history','Creator gifts','Tax / statements'].map((x, i) => <Pressable key={x} style={styles.optionRow} onPress={() => showToast(x, `${x} opened.`)}><Ionicons name={['phone-portrait','card','receipt','gift','document-text'][i]} color={colors.teal} size={20} /><Text style={styles.optionRowText}>{x}</Text><Ionicons name="chevron-forward" color={colors.textMuted} size={18} /></Pressable>)}</ScrollView></View>;
}


function SubscriptionScreen({ onBack, session }) {
  const fallbackPlans = [
    { code: 'free', name: 'Free', monthlyKes: 0 },
    { code: 'learner_plus', name: 'Learner Plus', monthlyKes: 299 },
    { code: 'creator_pro', name: 'Creator Pro', monthlyKes: 799 },
  ];
  const [plans, setPlans] = useState(fallbackPlans);
  const [planCode, setPlanCode] = useState(session?.role === 'teacher' ? 'creator_pro' : 'learner_plus');
  const [provider, setProvider] = useState('mpesa');
  const [phone, setPhone] = useState('');
  const [reference, setReference] = useState('');
  useEffect(() => {
    let alive = true;
    api.billing.plans().then((result) => {
      const next = result?.data?.plans || [];
      if (alive && Array.isArray(next) && next.length) setPlans(next);
    }).catch(() => {});
    return () => { alive = false; };
  }, []);
  async function checkout() {
    if (session?.isSchoolLinked) return showToast('Already linked', session?.accessActive ? 'Your ShuleAI school subscription is active.' : 'Ask your parent or school to activate your ShuleAI subscription.');
    if (!phone.trim()) return showToast('Phone needed', 'Enter the M-Pesa number to prompt.');
    try {
      const result = await api.billing.checkout(session?.id, planCode, provider, phone);
      if (result?.data?.noPaymentRequired) return showToast('Active', result?.data?.message || 'No payment required.');
      setReference(result?.data?.reference || '');
      showToast('Prompt sent', `Reference: ${result?.data?.reference || 'pending'}`);
    } catch (error) {
      showToast('Checkout failed', error.message || 'Payment could not start.');
    }
  }
  async function checkPayment() {
    if (!reference) return;
    try {
      const result = await api.billing.status(reference);
      showToast('Payment status', result?.data?.paid ? 'Payment confirmed. Subscription active.' : `Status: ${result?.data?.status || 'pending'}`);
    } catch (error) { showToast('Status failed', error.message || 'Could not check payment.'); }
  }
  const linkedActive = session?.isSchoolLinked && session?.accessActive;
  const linkedPending = session?.isSchoolLinked && !session?.accessActive;
  return <View style={styles.page}><TopBar title="Subscription" onBack={onBack} /><ScrollView contentContainerStyle={{ padding: 16 }}><View style={styles.publicBanner}><Ionicons name={linkedActive ? "shield-checkmark" : "person-circle"} color={colors.teal} size={22} /><Text style={styles.publicBannerText}>{linkedActive ? 'Linked school subscription active.' : linkedPending ? 'Linked to ShuleAI school account. Subscription is handled in the school platform.' : `LearnFeed ID: ${session?.learnFeedId || 'new account'}`}</Text></View>{linkedActive || linkedPending ? null : <><SectionTitle title="PLAN" />{plans.map(p => <Pressable key={p.code || p.name} style={[styles.planRow, planCode === (p.code || p.name) && { borderColor: colors.teal }]} onPress={() => setPlanCode(p.code || p.name)}><View><Text style={styles.planName}>{p.name}</Text><Text style={styles.planSub}>KSh {Number(p.monthlyKes || 0).toLocaleString()} / month</Text></View>{planCode === (p.code || p.name) && <Ionicons name="checkmark-circle" color={colors.teal} size={22} />}</Pressable>)}<SectionTitle title="PAYMENT" /><View style={styles.segmentRow}>{['mpesa'].map(p => <Pill key={p} label={p.toUpperCase()} active={provider === p} onPress={() => setProvider(p)} />)}</View><Field label="M-Pesa phone" value={phone} onChangeText={setPhone} placeholder="07XXXXXXXX" keyboardType="phone-pad" /><Pressable style={styles.primaryBtn} onPress={checkout}><Text style={styles.primaryBtnText}>Prompt Phone to Pay</Text><Ionicons name="phone-portrait" color="#fff" size={18} /></Pressable>{reference ? <Pressable style={styles.secondaryBtn} onPress={checkPayment}><Text style={styles.secondaryBtnText}>Check Payment Status</Text></Pressable> : null}</>}</ScrollView></View>;
}


function SettingsScreen({ onBack, session, setSession }) {
  const [privateAccount, setPrivateAccount] = useState(false);
  const [comments, setComments] = useState(true);
  const [duet, setDuet] = useState(true);
  const [downloads, setDownloads] = useState(true);
  return <View style={styles.page}><TopBar title="Settings & Privacy" onBack={onBack} /><ScrollView contentContainerStyle={{ padding: 16 }}><Field label="Display name" value={session.displayName} onChangeText={(t) => setSession(s => ({ ...s, displayName: t }))} /><ToggleRow label="Private account" value={privateAccount} onChange={setPrivateAccount} /><ToggleRow label="Allow comments" value={comments} onChange={setComments} /><ToggleRow label="Allow duet/stitch" value={duet} onChange={setDuet} /><ToggleRow label="Allow downloads" value={downloads} onChange={setDownloads} />{['Security','Blocked accounts','Notification settings','Content preferences','Help Center'].map((x, i) => <Pressable key={x} style={styles.optionRow} onPress={() => showToast(x, `${x} opened.`)}><Ionicons name={['lock-closed','ban','notifications','options','help-circle'][i]} color={colors.teal} size={20} /><Text style={styles.optionRowText}>{x}</Text><Ionicons name="chevron-forward" color={colors.textMuted} size={18} /></Pressable>)}</ScrollView></View>;
}

function NotificationsScreen({ onBack, open, routeTab, videos }) {
  const items = [
    { icon: 'heart', color: colors.pink, text: 'Grace liked your Chemistry lesson.', action: () => open('video', videos[0]) },
    { icon: 'chatbubble', color: colors.teal, text: 'Kevin commented: Can you explain endpoint?', action: () => open('comments', videos[0]) },
    { icon: 'radio', color: colors.pink, text: 'Miss Amina is live now.', action: () => open('liveRoom', liveRoomsSeed[0]) },
    { icon: 'mail', color: colors.gold, text: 'New message request.', action: () => routeTab('inbox') },
    { icon: 'card', color: colors.green, text: 'Subscription payment receipt ready.', action: () => open('subscription') },
  ];
  return <View style={styles.page}><TopBar title="Notifications" onBack={onBack} /><ScrollView contentContainerStyle={{ padding: 16 }}>{items.map((n, i) => <Pressable key={i} style={styles.notifRow} onPress={n.action}><View style={[styles.notifIcon, { backgroundColor: `${n.color}22` }]}><Ionicons name={n.icon} color={n.color} size={20} /></View><Text style={styles.notifText}>{n.text}</Text><Ionicons name="chevron-forward" color={colors.textMuted} size={18} /></Pressable>)}</ScrollView></View>;
}

function ReportScreen({ video, onBack }) {
  const reasons = ['Misinformation', 'Bullying or harassment', 'Copyright issue', 'Spam', 'Dangerous content', 'Other'];
  return <View style={styles.page}><TopBar title="Report" onBack={onBack} /><ScrollView contentContainerStyle={{ padding: 16 }}><Text style={styles.reportTitle}>Why are you reporting this lesson?</Text>{reasons.map(r => <Pressable key={r} style={styles.optionRow} onPress={() => { showToast('Report submitted', `${r} report submitted for review.`); onBack(); }}><Ionicons name="flag-outline" color={colors.warning} size={20} /><Text style={styles.optionRowText}>{r}</Text><Ionicons name="chevron-forward" color={colors.textMuted} size={18} /></Pressable>)}</ScrollView></View>;
}

function BottomTabs({ active, onChange }) {
  const tabs = [
    { key: 'feed', label: 'Home', icon: 'home-outline', on: 'home' },
    { key: 'discover', label: 'Discover', icon: 'search-outline', on: 'search' },
    { key: 'create', label: '', icon: 'add', on: 'add', create: true },
    { key: 'inbox', label: 'Inbox', icon: 'chatbubble-outline', on: 'chatbubble', badge: 3 },
    { key: 'profile', label: 'Profile', icon: 'person-outline', on: 'person' },
  ];
  return <View style={styles.bottomTabs}>{tabs.map(t => <Pressable key={t.key} style={styles.bottomTab} onPress={() => onChange(t.key)}>{t.create ? <View style={styles.createTab}><View style={styles.createLeft} /><View style={styles.createRight} /><Ionicons name="add" color="#000" size={26} /></View> : <><View><Ionicons name={active === t.key ? t.on : t.icon} color={active === t.key ? '#fff' : colors.textMuted} size={24} />{t.badge && <View style={styles.navBadge}><Text style={styles.navBadgeText}>{t.badge}</Text></View>}</View><Text style={[styles.bottomTabText, active === t.key && { color: '#fff' }]}>{t.label}</Text></>}</Pressable>)}</View>;
}

function TopBar({ title, onBack, right }) {
  return <View style={styles.topBar}><Pressable onPress={onBack} hitSlop={10}><Ionicons name="chevron-back" color="#fff" size={26} /></Pressable><Text style={styles.topBarTitle}>{title}</Text>{right || <View style={{ width: 26 }} />}</View>;
}
function Field({ label, value, onChangeText, placeholder, keyboardType, multiline, autoCapitalize = 'none' }) { return <><Text style={styles.label}>{label}</Text><TextInput style={[styles.input, multiline && { height: 90, textAlignVertical: 'top', paddingTop: 12 }]} value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor={colors.textMuted} keyboardType={keyboardType} autoCapitalize={autoCapitalize} multiline={multiline} /></>; }
function RolePill({ icon, title, active, onPress }) { return <Pressable style={[styles.rolePill, active && styles.rolePillActive]} onPress={onPress}><Text style={styles.roleIcon}>{icon}</Text><Text style={[styles.roleText, active && { color: colors.teal }]}>{title}</Text></Pressable>; }
function Pill({ label, active, onPress }) { return <Pressable style={[styles.pill, active && styles.pillActive]} onPress={onPress}><Text style={[styles.pillText, active && styles.pillTextActive]}>{label}</Text></Pressable>; }
function RailButton({ icon, label, onPress, color = '#fff' }) { return <Pressable style={styles.railBtn} onPress={onPress}><Ionicons name={icon} color={color} size={30} /><Text style={styles.railLabel}>{label}</Text></Pressable>; }
function SectionTitle({ title, action, onPress }) { return <View style={styles.sectionHead}><Text style={styles.sectionTitle}>{title}</Text>{action && <Pressable onPress={onPress}><Text style={styles.sectionAction}>{action}</Text></Pressable>}</View>; }
function ToggleRow({ label, value, onChange }) { return <Pressable style={styles.optionRow} onPress={() => onChange(!value)}><Text style={styles.optionRowText}>{label}</Text><View style={[styles.toggle, value && styles.toggleOn]}><View style={[styles.toggleDot, value && styles.toggleDotOn]} /></View></Pressable>; }
function PickerRow({ label, value, options, onChange }) { return <View style={{ marginBottom: 14 }}><Text style={styles.label}>{label}</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>{options.map(o => <Pill key={o} label={o} active={value === o} onPress={() => onChange(o)} />)}</ScrollView></View>; }
function Stat({ value, label }) { return <View style={styles.stat}><Text style={styles.statVal}>{value}</Text><Text style={styles.statLbl}>{label}</Text></View>; }
function Divider() { return <View style={styles.statDivider} />; }
function ToolButton({ icon, label, onPress }) { return <Pressable style={styles.toolButton} onPress={onPress}><Ionicons name={icon} color={colors.teal} size={22} /><Text style={styles.toolButtonText}>{label}</Text></Pressable>; }
function Metric({ label, value, icon, color }) { return <View style={styles.metricCard}><Ionicons name={icon} color={color} size={22} /><Text style={[styles.metricValue, { color }]}>{value}</Text><Text style={styles.metricLabel}>{label}</Text></View>; }

const styles = StyleSheet.create({
  shell: { flex: 1, backgroundColor: colors.bg },
  page: { flex: 1, backgroundColor: colors.bg },
  pageWithNav: { flex: 1, backgroundColor: colors.bg, paddingBottom: TAB_H },
  glowTop: { position: 'absolute', width: 320, height: 320, borderRadius: 160, backgroundColor: 'rgba(0,194,186,0.1)', top: -120, right: -80 },
  glowBot: { position: 'absolute', width: 300, height: 300, borderRadius: 150, backgroundColor: 'rgba(255,59,92,0.07)', bottom: -100, left: -80 },
  loginPage: { flex: 1, backgroundColor: colors.bg, overflow: 'hidden' },
  loginScroll: { flexGrow: 1, alignItems: 'center', justifyContent: 'center', padding: 20, paddingBottom: 40 },
  logoBlock: { alignItems: 'center', marginBottom: 24 },
  logoCircle: { width: 76, height: 76, borderRadius: 20, backgroundColor: colors.blue, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  logoName: { color: colors.teal, fontSize: 30, fontWeight: '900', letterSpacing: 1 },
  logoSub: { color: colors.textSub, fontSize: 10, fontWeight: '800', letterSpacing: 2, marginTop: 3 },
  cardXL: { width: '100%', maxWidth: 430, backgroundColor: colors.bgCard, borderRadius: 22, borderWidth: 1, borderColor: colors.line, padding: 22 },
  cardTitle: { color: '#fff', fontSize: 23, fontWeight: '900', marginTop: 10, marginBottom: 4 },
  cardSub: { color: colors.textSub, fontSize: 13, lineHeight: 19, marginBottom: 16 },
  publicBanner: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: 'rgba(0,194,186,0.08)', borderRadius: 14, padding: 13, borderWidth: 1, borderColor: 'rgba(0,194,186,0.22)', marginBottom: 16 },
  publicBannerText: { flex: 1, color: colors.textSub, fontSize: 12, lineHeight: 17 },
  label: { color: colors.textSub, fontSize: 12, fontWeight: '800', marginBottom: 7 },
  input: { minHeight: 48, backgroundColor: colors.bgInput, borderRadius: 12, paddingHorizontal: 14, color: '#fff', borderWidth: 1, borderColor: colors.line, marginBottom: 14 },
  passWrap: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14 },
  eyeBtn: { width: 44, height: 48, alignItems: 'center', justifyContent: 'center' },
  primaryBtn: { minHeight: 52, backgroundColor: colors.teal, borderRadius: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, paddingHorizontal: 14, marginTop: 8 },
  primaryBtnText: { color: '#fff', fontWeight: '900', fontSize: 16 },
  secondaryBtn: { minHeight: 48, borderRadius: 14, borderWidth: 1, borderColor: colors.teal, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 14, marginTop: 10 },
  secondaryBtnText: { color: colors.teal, fontWeight: '900', fontSize: 14 },
  roleRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  rolePill: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 999, backgroundColor: colors.bgInput, borderWidth: 1, borderColor: colors.line },
  rolePillActive: { backgroundColor: 'rgba(0,194,186,0.18)', borderColor: colors.teal },
  roleIcon: { fontSize: 16 },
  roleText: { color: colors.textSub, fontSize: 12, fontWeight: '800' },
  pill: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, backgroundColor: colors.bgInput, borderWidth: 1, borderColor: colors.line, marginRight: 6, marginBottom: 6 },
  pillActive: { backgroundColor: colors.teal, borderColor: colors.teal },
  pillText: { color: colors.textSub, fontWeight: '800', fontSize: 12 },
  pillTextActive: { color: '#fff' },
  segmentRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 10 },

  feedItem: { width: '100%', overflow: 'hidden', backgroundColor: '#070a12' },
  videoLayer: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  visualOrb: { position: 'absolute', width: 360, height: 360, borderRadius: 180 },
  videoEmoji: { fontSize: 145, opacity: 0.35 },
  bgFormula: { position: 'absolute', top: 170, left: 20, color: 'rgba(255,255,255,0.12)', fontSize: 24, fontWeight: '900' },
  feedTop: { position: 'absolute', top: 48, left: 14, right: 58, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', zIndex: 10 },
  feedTopLeft: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  subjectBadge: { backgroundColor: colors.teal, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 5 },
  subjectText: { color: '#fff', fontWeight: '900', fontSize: 11 },
  classBadge: { backgroundColor: 'rgba(255,255,255,0.18)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 5 },
  classText: { color: '#fff', fontWeight: '800', fontSize: 11 },
  feedTabsRow: { position: 'absolute', top: 88, left: 14, right: 14, flexDirection: 'row', gap: 22, zIndex: 10 },
  feedTab: { color: 'rgba(255,255,255,0.55)', fontWeight: '800', fontSize: 16, paddingBottom: 5 },
  feedTabActive: { color: '#fff', borderBottomWidth: 2, borderBottomColor: '#fff' },
  liveBadge: { position: 'absolute', top: 128, left: 14, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: colors.pink, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999 },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#fff' },
  liveBadgeText: { color: '#fff', fontSize: 11, fontWeight: '900' },
  actionRail: { position: 'absolute', right: 10, bottom: 135, alignItems: 'center', gap: 17, zIndex: 10 },
  avatarWrap: { alignItems: 'center', marginBottom: 2 },
  railAvatar: { width: 46, height: 46, borderRadius: 23, borderWidth: 2, borderColor: '#fff', backgroundColor: '#222', alignItems: 'center', justifyContent: 'center' },
  avatarEmoji: { fontSize: 26 },
  followMini: { position: 'absolute', bottom: -8, width: 20, height: 20, borderRadius: 10, backgroundColor: colors.pink, alignItems: 'center', justifyContent: 'center' },
  railBtn: { alignItems: 'center', gap: 3 },
  railLabel: { color: '#fff', fontSize: 11, fontWeight: '900' },
  soundDisc: { width: 38, height: 38, borderRadius: 19, backgroundColor: 'rgba(0,0,0,0.45)', borderWidth: 1, borderColor: colors.lineStrong, alignItems: 'center', justifyContent: 'center' },
  bottomInfo: { position: 'absolute', bottom: 14, left: 14, right: 64, zIndex: 10 },
  creatorRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 },
  creatorAvatar: { fontSize: 26, width: 34 },
  creatorNameRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  creatorName: { color: '#fff', fontWeight: '900', fontSize: 14 },
  creatorRole: { color: 'rgba(255,255,255,0.65)', fontSize: 11, marginTop: 1 },
  followBtn: { borderColor: '#fff', borderWidth: 1.3, paddingHorizontal: 13, paddingVertical: 5, borderRadius: 5 },
  followingBtn: { backgroundColor: 'rgba(255,255,255,0.16)', borderColor: 'transparent' },
  followBtnText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  clipTitle: { color: '#fff', fontWeight: '900', fontSize: 16, marginBottom: 4 },
  clipDesc: { color: 'rgba(255,255,255,0.75)', fontSize: 13, lineHeight: 19, marginBottom: 8 },
  soundRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 10 },
  soundText: { color: 'rgba(255,255,255,0.7)', fontSize: 12 },
  quickBtns: { flexDirection: 'row', gap: 7, flexWrap: 'wrap' },
  aiBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(11,47,107,0.9)', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, borderWidth: 1, borderColor: colors.teal },
  aiBtnText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  quizBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: colors.teal, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20 },
  quizBtnText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  darkBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(255,255,255,0.14)', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20 },
  darkBtnText: { color: '#fff', fontWeight: '900', fontSize: 12 },

  floatingBell: { position: 'absolute', top: 52, right: 16, zIndex: 30, width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.45)', alignItems: 'center', justifyContent: 'center' },
  bellDot: { position: 'absolute', top: 8, right: 8, width: 8, height: 8, borderRadius: 4, backgroundColor: colors.pink, borderWidth: 1.5, borderColor: colors.bg },
  bottomTabs: { position: 'absolute', left: 0, right: 0, bottom: 0, height: TAB_H, backgroundColor: colors.navBg, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.07)', flexDirection: 'row', alignItems: 'center', paddingBottom: 4 },
  bottomTab: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 3, paddingTop: 4 },
  bottomTabText: { color: colors.textMuted, fontSize: 10, fontWeight: '700' },
  createTab: { width: 50, height: 34, borderRadius: 9, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  createLeft: { position: 'absolute', left: 0, top: 0, bottom: 0, width: '50%', backgroundColor: colors.teal, opacity: 0.85 },
  createRight: { position: 'absolute', right: 0, top: 0, bottom: 0, width: '50%', backgroundColor: colors.pink, opacity: 0.85 },
  navBadge: { position: 'absolute', top: -5, right: -8, backgroundColor: colors.pink, minWidth: 16, height: 16, borderRadius: 8, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3 },
  navBadgeText: { color: '#fff', fontSize: 9, fontWeight: '900' },

  topBar: { paddingTop: 50, paddingHorizontal: 16, paddingBottom: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: colors.line },
  topBarTitle: { flex: 1, color: '#fff', fontSize: 17, fontWeight: '900', marginLeft: 10 },
  headerPill: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(255,59,92,0.15)', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999 },
  headerPillText: { color: colors.pink, fontWeight: '900', fontSize: 12 },
  searchHeader: { paddingTop: 52, paddingHorizontal: 14, marginBottom: 12 },
  searchBar: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: colors.bgCard, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 11, borderWidth: 1, borderColor: colors.line },
  searchInput: { flex: 1, color: '#fff', fontSize: 14 },
  horizontalPills: { paddingHorizontal: 14, gap: 4, paddingBottom: 8 },
  sectionHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 0, marginTop: 10, marginBottom: 10 },
  sectionTitle: { color: colors.textMuted, fontSize: 11, fontWeight: '900', letterSpacing: 0.8 },
  sectionAction: { color: colors.teal, fontSize: 12, fontWeight: '900' },
  liveCard: { width: 152, height: 190, backgroundColor: colors.bgCard, borderRadius: 16, padding: 12, borderWidth: 1, borderColor: colors.line, overflow: 'hidden' },
  liveCardEmoji: { fontSize: 48, textAlign: 'center', marginTop: 12, marginBottom: 12 },
  livePill: { alignSelf: 'flex-start', backgroundColor: colors.pink, borderRadius: 999, paddingHorizontal: 8, paddingVertical: 3 },
  livePillText: { color: '#fff', fontSize: 10, fontWeight: '900' },
  liveCardTitle: { color: '#fff', fontSize: 13, fontWeight: '900', marginTop: 8, lineHeight: 18 },
  liveCardSub: { color: colors.textSub, fontSize: 11, marginTop: 4 },
  gridWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, paddingHorizontal: 14, paddingBottom: 20 },
  discoverCard: { width: (SW - 38) / 2, height: 172, borderRadius: 14, overflow: 'hidden' },
  discoverBg: { flex: 1, backgroundColor: colors.bgCard2, justifyContent: 'space-between', padding: 10 },
  discoverEmoji: { fontSize: 44, textAlign: 'center', marginTop: 16, opacity: 0.75 },
  discoverOverlay: {},
  discoverTitle: { color: '#fff', fontWeight: '900', fontSize: 13, lineHeight: 18 },
  miniMeta: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3 },
  miniMetaText: { color: 'rgba(255,255,255,0.65)', fontSize: 11 },

  cameraPanel: { backgroundColor: colors.bgCard, borderRadius: 18, borderWidth: 1, borderColor: colors.line, padding: 16, alignItems: 'center', marginBottom: 16 },
  cameraTop: { alignSelf: 'stretch', flexDirection: 'row', justifyContent: 'space-between' },
  recText: { color: colors.pink, fontWeight: '900', fontSize: 12 },
  cameraQuality: { color: colors.textSub, fontSize: 12, fontWeight: '800' },
  cameraEmoji: { fontSize: 82, marginVertical: 16 },
  cameraHint: { color: colors.textSub, textAlign: 'center', lineHeight: 19, marginBottom: 14 },
  cameraTools: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 10, marginBottom: 18 },
  cameraTool: { alignItems: 'center', width: 58, gap: 5 },
  cameraToolText: { color: colors.textSub, fontSize: 10, fontWeight: '800' },
  recordBtn: { width: 74, height: 74, borderRadius: 37, borderWidth: 4, borderColor: '#fff', alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  recordingBtn: { borderColor: colors.pink },
  recordInner: { width: 52, height: 52, borderRadius: 26, backgroundColor: colors.pink },
  smallMuted: { color: colors.textMuted, fontSize: 12, textAlign: 'center' },
  bigActionCard: { backgroundColor: colors.bgCard, borderRadius: 16, padding: 18, alignItems: 'center', borderWidth: 1, borderColor: colors.line, marginBottom: 14 },
  bigActionTitle: { color: '#fff', fontWeight: '900', fontSize: 18, marginTop: 10 },
  bigActionSub: { color: colors.textSub, textAlign: 'center', lineHeight: 19, marginVertical: 10 },
  previewCard: { height: 230, borderRadius: 18, backgroundColor: colors.bgCard, borderWidth: 1, borderColor: colors.line, alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  previewEmoji: { fontSize: 70, marginBottom: 8 },
  previewTitle: { color: '#fff', fontWeight: '900' },
  toolGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 16 },
  toolTile: { width: (SW - 52) / 2, backgroundColor: colors.bgCard, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.line, gap: 8 },
  toolTileText: { color: '#fff', fontWeight: '800', fontSize: 13 },
  optionRow: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.bgCard, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.line, marginBottom: 10 },
  optionRowText: { flex: 1, color: '#fff', fontWeight: '800', fontSize: 14 },
  toggle: { width: 46, height: 26, borderRadius: 13, backgroundColor: colors.bgInput, justifyContent: 'center', paddingHorizontal: 3 },
  toggleOn: { backgroundColor: colors.teal },
  toggleDot: { width: 20, height: 20, borderRadius: 10, backgroundColor: '#fff' },
  toggleDotOn: { alignSelf: 'flex-end' },

  screenHeader: { paddingTop: 52, paddingHorizontal: 16, paddingBottom: 14, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  screenTitle: { color: '#fff', fontSize: 24, fontWeight: '900' },
  inboxQuickRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  inboxQuick: { backgroundColor: colors.bgCard, borderRadius: 999, paddingHorizontal: 14, paddingVertical: 9, borderWidth: 1, borderColor: colors.line },
  inboxQuickText: { color: '#fff', fontWeight: '800', fontSize: 12 },
  messageRow: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.bgCard, borderRadius: 14, padding: 12, marginBottom: 10, borderWidth: 1, borderColor: colors.line },
  msgAvatarWrap: { width: 48, height: 48, borderRadius: 24, backgroundColor: colors.bgCard2, alignItems: 'center', justifyContent: 'center' },
  msgAvatar: { fontSize: 26 },
  onlineDot: { position: 'absolute', bottom: 2, right: 2, width: 12, height: 12, borderRadius: 6, backgroundColor: colors.green, borderWidth: 2, borderColor: colors.bgCard },
  msgName: { color: '#fff', fontWeight: '900', fontSize: 14 },
  msgLast: { color: colors.textSub, fontSize: 12, marginTop: 2 },
  unreadBadge: { minWidth: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.pink, paddingHorizontal: 6 },
  unreadText: { color: '#fff', fontSize: 11, fontWeight: '900' },
  bubble: { maxWidth: '82%', borderRadius: 16, padding: 12, marginBottom: 10 },
  myBubble: { alignSelf: 'flex-end', backgroundColor: colors.teal },
  theirBubble: { alignSelf: 'flex-start', backgroundColor: colors.bgCard },
  aiBubble: { alignSelf: 'flex-start', backgroundColor: colors.bgCard, borderWidth: 1, borderColor: 'rgba(0,194,186,0.2)' },
  bubbleText: { color: '#fff', lineHeight: 20 },
  bubbleTime: { color: 'rgba(255,255,255,0.7)', fontSize: 10, marginTop: 4, textAlign: 'right' },
  chatInputBar: { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: colors.navBg, borderTopWidth: 1, borderTopColor: colors.line, padding: 12, paddingBottom: 16 },
  chatInput: { flex: 1, minHeight: 42, backgroundColor: colors.bgInput, borderRadius: 21, paddingHorizontal: 14, color: '#fff' },
  sendBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.teal, alignItems: 'center', justifyContent: 'center' },

  profileTop: { paddingTop: 52, paddingHorizontal: 16, paddingBottom: 16 },
  profileHeaderRow: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 16 },
  bigAvatar: { width: 66, height: 66, borderRadius: 33, backgroundColor: colors.bgCard2, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: colors.teal },
  bigAvatarText: { fontSize: 34 },
  profileName: { color: '#fff', fontSize: 20, fontWeight: '900' },
  profileHandle: { color: colors.textSub, fontSize: 13, marginTop: 2 },
  statsRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  stat: { flex: 1, alignItems: 'center' },
  statVal: { color: '#fff', fontSize: 18, fontWeight: '900' },
  statLbl: { color: colors.textSub, fontSize: 12, marginTop: 2 },
  statDivider: { width: 1, height: 32, backgroundColor: colors.line },
  profileBio: { color: '#fff', fontSize: 13, lineHeight: 19, marginBottom: 14 },
  profileBtns: { flexDirection: 'row', gap: 10 },
  editProfileBtn: { flex: 1, backgroundColor: colors.bgCard, borderRadius: 10, padding: 11, alignItems: 'center', borderWidth: 1, borderColor: colors.line },
  editProfileText: { color: '#fff', fontWeight: '900' },
  iconSquare: { width: 42, height: 42, backgroundColor: colors.bgCard, borderRadius: 10, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.line },
  creatorToolsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, paddingHorizontal: 16, marginBottom: 20 },
  toolButton: { width: (SW - 42) / 2, backgroundColor: colors.bgCard, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.line, gap: 8 },
  toolButtonText: { color: '#fff', fontWeight: '800', fontSize: 13 },
  profileGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 1 },
  profileVideo: { width: '33.1%', aspectRatio: 0.72, backgroundColor: colors.bgCard2, alignItems: 'center', justifyContent: 'center' },
  profileVideoEmoji: { fontSize: 38, opacity: 0.6 },
  profileVideoMeta: { position: 'absolute', bottom: 6, left: 6, flexDirection: 'row', alignItems: 'center', gap: 3 },
  profileVideoViews: { color: '#fff', fontSize: 11, fontWeight: '800' },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, margin: 16, backgroundColor: 'rgba(255,59,92,0.1)', borderRadius: 12, padding: 14, borderWidth: 1, borderColor: 'rgba(255,59,92,0.3)' },
  logoutText: { color: colors.danger, fontWeight: '900', fontSize: 15 },

  commentRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.line },
  commentAvatar: { fontSize: 26, width: 34 },
  commentName: { color: '#fff', fontWeight: '900' },
  commentText: { color: '#fff', marginTop: 4, lineHeight: 20 },
  commentActions: { flexDirection: 'row', gap: 16, marginTop: 7 },
  commentAction: { color: colors.textMuted, fontSize: 12, fontWeight: '800' },
  pinPill: { backgroundColor: 'rgba(0,194,186,0.16)', borderRadius: 99, paddingHorizontal: 6, paddingVertical: 2 },
  pinText: { color: colors.teal, fontSize: 9, fontWeight: '900' },
  sharePreview: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.bgCard, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: colors.line, marginBottom: 16 },
  shareEmoji: { fontSize: 48 },
  shareTitle: { color: '#fff', fontSize: 15, fontWeight: '900' },
  shareSub: { color: colors.textSub, fontSize: 12, marginTop: 3 },
  shareGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  shareAction: { width: (SW - 56) / 4, alignItems: 'center', gap: 7 },
  shareIcon: { width: 54, height: 54, borderRadius: 27, backgroundColor: colors.bgCard, borderWidth: 1, borderColor: colors.line, alignItems: 'center', justifyContent: 'center' },
  shareActionText: { color: colors.textSub, fontSize: 11, textAlign: 'center', fontWeight: '800' },
  quizTopic: { color: colors.teal, fontWeight: '900', marginBottom: 10 },
  quizQuestion: { color: '#fff', fontSize: 22, fontWeight: '900', lineHeight: 29, marginBottom: 18 },
  quizOption: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: colors.bgCard, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.line, marginBottom: 10 },
  quizSelected: { borderColor: colors.teal },
  quizCorrect: { borderColor: colors.green, backgroundColor: 'rgba(0,200,117,0.1)' },
  quizWrong: { borderColor: colors.pink, backgroundColor: 'rgba(255,59,92,0.08)' },
  quizOptionText: { color: '#fff', fontWeight: '800' },
  resultCard: { backgroundColor: colors.bgCard, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: colors.line, marginTop: 12 },
  resultTitle: { color: '#fff', fontSize: 18, fontWeight: '900', marginBottom: 6 },
  resultSub: { color: colors.textSub, lineHeight: 20 },
  soundItem: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.bgCard, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.line, marginBottom: 10 },
  soundIcon: { width: 42, height: 42, borderRadius: 21, backgroundColor: 'rgba(0,194,186,0.12)', alignItems: 'center', justifyContent: 'center' },
  soundItemTitle: { color: '#fff', fontWeight: '900' },
  soundItemSub: { color: colors.textSub, fontSize: 12, marginTop: 2 },
  duetPreview: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  duetHalf: { flex: 1, height: 260, backgroundColor: colors.bgCard, borderRadius: 16, borderWidth: 1, borderColor: colors.line, alignItems: 'center', justifyContent: 'center' },
  liveStage: { minHeight: 430, backgroundColor: '#070a12', paddingTop: 50, paddingHorizontal: 14, alignItems: 'center' },
  liveTopBar: { alignSelf: 'stretch', flexDirection: 'row', alignItems: 'center', gap: 10 },
  liveHost: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(0,0,0,0.35)', borderRadius: 999, padding: 6 },
  liveHostAvatar: { fontSize: 24 },
  liveHostName: { color: '#fff', fontWeight: '900', fontSize: 12 },
  liveHostSub: { color: colors.textSub, fontSize: 10 },
  liveMainEmoji: { fontSize: 112, marginTop: 60, opacity: 0.9 },
  liveTitleBig: { color: '#fff', fontSize: 22, fontWeight: '900', textAlign: 'center', marginTop: 14 },
  liveButtons: { flexDirection: 'row', gap: 10, marginTop: 24 },
  liveAction: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(255,255,255,0.12)', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 8 },
  liveActionText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  liveChatList: { flex: 1, backgroundColor: colors.bg },
  liveChatLine: { color: '#fff', backgroundColor: 'rgba(255,255,255,0.06)', padding: 8, borderRadius: 10, marginBottom: 6, overflow: 'hidden' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  metricCard: { width: (SW - 42) / 2, backgroundColor: colors.bgCard, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.line, gap: 5 },
  metricValue: { fontSize: 22, fontWeight: '900' },
  metricLabel: { color: colors.textSub, fontSize: 12 },
  walletCard: { backgroundColor: colors.bgCard, borderRadius: 18, padding: 18, borderWidth: 1, borderColor: 'rgba(0,194,186,0.25)', marginBottom: 16 },
  walletLabel: { color: colors.textSub, fontWeight: '800' },
  walletAmount: { color: colors.teal, fontSize: 34, fontWeight: '900', marginVertical: 8 },
  walletSub: { color: colors.textSub, lineHeight: 19 },
  planRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: colors.bgCard, borderRadius: 14, borderWidth: 1, borderColor: colors.line, padding: 14, marginBottom: 10 },
  planName: { color: '#fff', fontWeight: '900', fontSize: 15 },
  planSub: { color: colors.textSub, fontSize: 12, marginTop: 3 },
  notifRow: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.bgCard, borderRadius: 14, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: colors.line },
  notifIcon: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  notifText: { flex: 1, color: '#fff', lineHeight: 20, fontWeight: '700' },
  reportTitle: { color: '#fff', fontSize: 18, fontWeight: '900', marginBottom: 16 },
});
