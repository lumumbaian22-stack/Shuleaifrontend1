# Shule AI LearnFeed APK Build

This project is configured to produce an installable Android APK.

## Build the APK

1. Install dependencies:

   npm install

2. Log in to Expo/EAS if building in the cloud:

   npx eas login

3. Build an installable APK:

   npm run build:android:apk

The generated APK download link will come from EAS after the build finishes.

## Local APK build

If Android Studio, Java, and the Android SDK are installed locally, you can try:

   npm run build:android:apk:local

## Backend

The app is configured to use:

https://shuleaibackend-32h1.onrender.com/api/learnfeed

## Android identity

Package name: com.shuleai.learnfeed
Version code: 6
