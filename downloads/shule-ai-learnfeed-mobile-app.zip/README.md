# Shule AI LearnFeed — Full TikTok-Style Frontend v6

This is a clean frontend rebuild for the public Student + Teacher/Creator app.

It is **not school-locked**:
- No parent dashboard
- No admin dashboard
- No school code
- Public individual users only
- Student and Teacher / Creator roles only
- User-based subscription/payment flow

## What is included in the frontend

This version is built to behave like a full TikTok-style education frontend:

- Vertical For You feed
- Following feed
- STEM feed
- Live feed entry
- Like, save, follow, comment, share
- Native share sheet trigger
- Duet / Stitch / Remix frontend flow
- Sound library
- Effects library
- Video detail screen
- Comments with posting
- AI Tutor chat
- Quiz with XP result
- Discover/search screen
- Trending grid
- Live rooms list
- Watch live screen with chat, gifts, hearts, co-host request
- Host live screen
- Creator recording studio frontend
- Upload frontend flow
- Edit tools: captions, green screen, whiteboard, formula overlay, quiz sticker
- Post settings: visibility, comments, duet, stitch
- Published lesson is added to the feed immediately
- Inbox, messages, chat sending
- Notifications with redirects
- Public profile
- Creator Studio
- Wallet/payout frontend
- Subscription/payment frontend
- Settings and privacy frontend
- Report flow

## Important truth

This is a **full frontend**. Real TikTok-level production still needs backend services for:

- Real authentication
- Actual video camera/media picker integration
- Video storage
- Video streaming/CDN
- Recommendation algorithm
- Real comments/follows/likes database
- Real live streaming server
- Push notifications
- Payment provider credentials
- Creator payout processing
- Moderation backend

The frontend API contract is in:

```txt
src/api/client.js
```

## Run with Expo Go on Windows CMD

After extracting the ZIP:

```cmd
cd "C:\Users\ezeh\Downloads\shule-ai-learnfeed-full-tiktok-frontend-v6"
if exist node_modules rmdir /s /q node_modules
npm install
npx expo start -c --lan
```

Use LAN first. Use tunnel only if LAN fails and ngrok is working:

```cmd
npx expo start -c --tunnel
```

## Tested

The Android Expo bundle was tested with:

```cmd
npx expo export --platform android
```

It bundled successfully.
